## O que foi implementado/resolvido?

> **Nota:** Preencher somente os campos que fazem sentido à essa merge request. Demais campos desnecessários, podem e devem ser removidos.

Aqui uma breve descrição do que foi resolvido/implementado

---

#### Tarefas vinculadas

[<EDITAR>Id da tarefa - Título da tarefa](https://app.clickup.com/t/<Link_da_tarefa_aqui>)

---

#### Categoria da mudança
- [ ] Change/migration (versões das dependências/bibliotecas)
- [ ] Feature (nova funcionalidade)
- [ ] Correção (bugfix)
- [ ] Rollback (regressão de funcionalidade)
- [ ] Feature flag enable (ativação de funcionalidade)
- [ ] Feature flag removal (remoção de funcionalidade)
- [ ] Security issue (vulnerabilidade/segurança)

---

#### Serviços impactados

Quais partes do sistema podem ser afetadas por esse merge:

- [ ] Greenn - Adm
- [ ] Greenn - Assinaturas
- [ ] Greenn - Checkout
- [ ] Greenn - Club
- [ ] Greenn - Envios
- [ ] Greenn - ERP
- [ ] Greenn - Gateway
- [ ] Greenn - Mensagens
- [ ] Greenn - Pagamentos
- [ ] Greenn - Reclamação
- [ ] Greenn - Sales

---

#### Horário recomendado para deploy

- [ ] Baixo risco - 08h até às 17h - Pode ser feito em horário comercial
- [ ] Médio risco - 22h até às 23h - Deve ser feito fora de horário comercial
- [ ] Alto risco  - 00h até às 04h - Não deve ser feito em horário comercial

> **Nota:** Evitar de fazer deploys em horários de lançamento, que varia das 18h até às 21h.

---

#### Há alteração/adição de variáveis de ambiente?

Devem ser adicionados os seguintes parâmetros novos:

```bash
#venv
TOKEN_PAGARME_V5=ahsaushausahs
PAGARME_V5_API_URL=https://api.teste.me/core/v5

#global settings
PAGARME_V5=false
```

---

#### Considerações pré/pós deploy?

1. Serviços de fila devem estar parados
2. Conexões com o banco de dados devem ser interrompidas
3. O deploy deve ocorrer fora do horário comercial

---

#### Existem comandos bash à serem executados após o deploy?

Os seguintes comandos deve ser executados após o deploy em ordem cronológica.

```bash
# Adicionar os comandos em ordem cronológica
php artisan migrate
```

---

#### Existem comandos SQL à serem executados?

Os seguintes comandos deve ser executados após o deploy em ordem cronológica no MySQL.

```sql
UPDATE SCHEME.TABELA SET CAMPO="NOVO VALOR DO CAMPO" WHERE CONDICAO=1;
```
