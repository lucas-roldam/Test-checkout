<script setup>
import { defineProps, defineEmits } from 'vue';

const props = defineProps({
  id: {
    type: [String, Number],
    required: true,
    default: () => 1,
  },
  checked: {
    type: Boolean,
    required: false,
    default: () => false,
  },
  label: {
    type: String,
    required: false,
    default: () => "",
  },
  labelCustomClass: {
    type: String,
    required: false,
    default: () => "",
  },
  disabled: {
    type: Boolean,
    required: false,
    default: () => false,
  },
  saveData: {
    type: Boolean,
    required: false,
    default: () => false,
  },
});

const emit = defineEmits(["update:checked", "click"]);

const handleChange = (event) => {
  emit('update:checked', event.target.checked);
  emit('click', event); // Emite o evento "click" diretamente do checkbox
};
</script>
<style lang="scss" scoped>
  .border-check{
    border-color: var(--main-color);
  }
  .bg-check{
    background-color: var(--main-color);
    color: var(--white); 
  }
</style>

<template>
  <input
    type="checkbox"
    @change="handleChange"
    @click="emit('click', $event)" 
    :checked="checked"
    :id="`checkbox-${id}`"
    class="mr-2 hidden"
    :disabled="disabled"
  />
  <label
    v-if="saveData"
    :for="`checkbox-${id}`"
    class="flex cursor-pointer select-none items-center gap-3"
  >
    <div
    :class="[
        'flex items-center justify-center rounded h-6 w-6 border-2 border-check',
        checked ? 'bg-check' : ''
      ]"
    
    >
      <div class="flex h-4 w-4 items-center justify-center" v-if="checked">
        <Icon name="mdi:check-bold" />
      </div>
    </div>
    <span class="text-sm text-txt-color">{{ label }}</span>
  </label>

  <label
    v-else
    :for="`checkbox-${id}`"
    class="flex cursor-pointer select-none flex-row items-center gap-3 font-bold"
  >
    <div class="flex h-4 w-4 items-center justify-center rounded bg-white">
      <Icon name="mdi:check-bold" v-if="checked" />
    </div>
    <span class="flex-wrap text-sm" :class="labelCustomClass">{{ label }}</span>
  </label>
</template>
