<script setup>
import { useRequestURL, useRuntimeConfig } from '#app'

import { storeToRefs } from "pinia";
import { useCustomCheckoutStore } from "~~/store/customCheckout";
import { useProductStore } from "~~/store/product";
import { useStepStore } from "~~/store/modules/steps";
import greenn from "../../assets/logos/logo.png";

const customCheckStore = useCustomCheckoutStore();
const product = useProductStore();
const stepStore = useStepStore();
const runtimeConfig = useRuntimeConfig();
const requestURL = useRequestURL();

const { topThumb, hasScarcity, hasCustomLogo, isOneStep } =
  storeToRefs(customCheckStore);
const { getCountSteps, currentStep, isMobile } = storeToRefs(stepStore);

const apiUrls = "http://localhost:3000,https://cadernointeligentecheckout.com.br,https://checkoutstg.cadernointeligentecheckout.com.br,https://neymarjrcadernodigital.com.br";
const urlOrigin = requestURL.origin;
const envIcon = "https://greenn-production-public.s3.us-east-1.amazonaws.com/edutech/LOGO+NEYMAR+preta+.svg";

let enabledLogo = false;

if (apiUrls.includes(urlOrigin)) {
  enabledLogo = true;
} else {
  enabledLogo = false;
}

const currentUrl = computed(() => {
  if (process.client) {
    return window.location.origin;
  }
  return null;
});

const isCurrentUrlInEnv = computed(() => {
  if (currentUrl.value) {
    if (!apiUrls.includes(currentUrl.value)) {
      enabledLogo = true;
    }
  }
  return enabledLogo;
});

onMounted(async() => {
  await stepStore.setMobileV2();
  stepStore.initializeStep();
});
</script>

<template>
  <Scarcity v-if="product.isValid() && hasScarcity" />
  <header
    v-if="topThumb && product.isValid()"
    class="flex max-h-[45vh] w-full max-w-[1250px] items-center justify-center rounded-lg"
    :class="{ '-mt-10': hasScarcity }"
  >
    <img :src="topThumb" alt="Thumb superior" class="rounded-lg" />
  </header>
  <header
    v-if="!hasScarcity && !topThumb && product.isValid()"
    class="header sticky top-0 z-50 flex min-h-[60px] w-full items-center justify-between bg-checkout px-4"
  >
    <template v-if="enabledLogo"> 
      <a>
        <img
          :src="hasCustomLogo ? hasCustomLogo : envIcon"
          alt="Logo da pagina"
          class="max-h-10 max-w-[100px] object-contain"
          width="100"
          height="40"
        />
      </a>
      <div class="steps flex" v-if="isMobile && !isOneStep">
        <div
          class="mx-1 h-2 w-2 rounded-full"
          :class="{
            'bg-main-color': item == currentStep,
            'bg-main-transparent-color': item != currentStep,
          }"
          v-for="item in getCountSteps"
          :key="item"
        ></div>
      </div>
    </template>
    <template v-else> 
      <a :href="'https://greenn.com.br/'" target="_blank">
        <img
          :src="hasCustomLogo ? hasCustomLogo : greenn"
          alt="Logo da pagina"
          class="max-h-10 max-w-[100px] object-contain"
          width="100"
          height="40"
        />
      </a>
      <div class="steps flex" v-if="isMobile && !isOneStep">
        <div
          class="mx-1 h-2 w-2 rounded-full"
          :class="{
            'bg-main-color': item == currentStep,
            'bg-main-transparent-color': item != currentStep,
          }"
          v-for="item in getCountSteps"
          :key="item"
        ></div>
      </div>
    </template>
  </header>
</template>
<style lang="scss" scoped>
.header {
  box-shadow: 2px 6px 10px rgba(0, 0, 0, 0.05);
}
</style>
