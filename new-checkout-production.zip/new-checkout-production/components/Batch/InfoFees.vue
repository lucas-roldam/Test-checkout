<template>
  <div class="flex justify-end">
    <small class="text-gray-400 hover:text-txt-color hover:cursor-pointer">Entenda as taxas</small>
  </div>
</template>