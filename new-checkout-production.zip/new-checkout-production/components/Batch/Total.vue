<script setup>
import { useAmountStore } from "~~/store/modules/amount";
import { useInstallmentsStore } from "~~/store/modules/installments";
import { useCheckoutStore } from "~~/store/checkout";
import { useProductStore } from "~~/store/product";

const amount = computed(() => {
  const { amount } = useAmountStore();
  return amount;
})

const maxInstallmentOfTickets = computed(() => {  
  const { maxInstallmentOfTickets } = useProductStore();
  return maxInstallmentOfTickets;
});

const ticketFees = computed(() => {  
  const { hasFees } = useProductStore();
  return !hasFees;
});

const installmentsTickets = computed(() => {
  const { getInstallmentsTickets } = useInstallmentsStore();
  const { maxInstallmentOfTickets } = useProductStore();
  return formatMoney(getInstallmentsTickets(amount.value, maxInstallmentOfTickets));
})
</script>

<template>
  <div class="mb-5 md:mb-0">
    <p class="text-[14px] font-[400] text-[#81858E]">{{ $t("pre_checkout.total") }}</p>
    <p class="text-[24px] font-[700] text-input-color">{{ formatMoney(amount) }}</p>
    <p v-if="amount > 0" class="text-[14px] font-[400] text-main-color">
      {{ $t("pre_checkout.or") }} {{ maxInstallmentOfTickets }}x de {{ installmentsTickets }} {{ ticketFees ? " (Sem juros)" : "" }}
    </p>
  </div>
</template>