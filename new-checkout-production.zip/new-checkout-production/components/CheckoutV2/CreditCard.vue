<template>
  <section class="w-full flex flex-col gap-5">
    <div class="form-section">
      <label for="card-number">Número do cartão</label>
      <div class="card-number-wrapper">
        <input
          class="input-text"
          type="text"
          id="card-number"
          placeholder="Digite o número do cartão"
          v-model="first.number"
          @input="formatCardNumber" 
          maxlength="19"
        />
      </div>
    </div>
    <div class="expiration">
      <div class="expiration-wrapper">
        <label for="expiration-month">Mês de expiração</label>
        <select
          id="expiration-month"
          v-model="first.month"
          class="input-select"
          :class="{ 'placeholder-active': first.month === '' }"
          @blur="onBlur()"
        >
          <option disabled value="">Mês</option>
          <option
            class="input-text"
            v-for="month in 12"
            :key="month"
            :value="String(month).padStart(2, '0')"
          >
            {{ String(month).padStart(2, '0')}}
          </option>
        </select>
      </div>
      <div class="expiration-wrapper">
        <label for="expiration-year">Ano</label>
        <select
          id="expiration-year"
          v-model="first.year"
          class="input-select"
          :class="{ 'placeholder-active': first.year === '' }"
          @blur="onBlur()"
        >
          <option disabled value="">Ano</option>
          <option
            class="input-text"
            v-for="year in expirationYears"
            :key="year"
            :value="year"
          >
            {{ year }}
          </option>
        </select>
      </div>
    </div>
    <div>
      <label for="cvv">CVV</label>
      <input
        mask="####"
        class="input-text"
        type="password" 
        id="cvv" 
        placeholder="Digite o CVV" 
        v-model="first.cvv"
        @input="validateCVV" 
        maxlength="3"
        @click="flipCard(true)"
        @blur="onBlur('card_cvv')"
        @focus="flipCard(true)"
      />
    </div>
    <div>
      <label for="cardholder-name">Nome do titular</label>
      <input
        class="input-text"
        type="text"
        id="cardholder-name"
        placeholder="Digite o nome do titular"
        v-model="first.holder_name"
        @click="onFocus('name')"
        @blur="onBlur('holder_name')"
      />
    </div>
    <label for="installments" class="installments">Parcelas</label>
    <BaseSelect
      class="input-text col-span-12 sm:col-span-4"
      v-model="installments"
    >
      <option
        :value="fixed_installments"
        v-if="!!fixed_installments"
        class="cursor-pointer select-none rounded hover:bg-white"
        translate="no"
      >
        {{
          `${fixed_installments}x ${hasFees ? "" : "(Sem juros)"} ${$t(
            "order.de"
          )} ${formatMoney(getInstallments())}${hasFees ? "*" : ""}`
        }}
      </option>
      <option
        v-else
        v-for="(d, index) in minInstallments"
        :key="index"
        :value="d"
        class="input-text cursor-pointer select-none rounded hover:bg-white"
        translate="no"
      >
        {{
          index + 1 > 1
            ? `${index + 1}x ${hasFees ? "" : "(Sem juros)"} ${$t(
                "order.de"
              )} ${formatAmountText(index + 1)}${
                hasFees ? "*" : ""
              }`
            : `${index + 1}x ${$t("order.de")} ${formatAmountText(1)}`
        }}
      </option>
    </BaseSelect>
  </section>
</template>

<script setup>
import { ref, watch, onMounted, computed } from "vue";
// Moment
import moment from "moment";
// Utils
import { formatMoney } from "~~/utils/money";
// Stores
import { useCheckoutStore } from "@/store/checkout";
import { usePurchaseStore } from "@/store/forms/purchase";
import { usePaymentStore } from "@/store/modules/payment";
import { useInstallmentsStore } from "~~/store/modules/installments";
import { useAmountStore } from  "~~/store/modules/amount";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
// Validation
import {
  validateThristStep
} from "@/rules/form-validations";


const checkout = useCheckoutStore();
const installmentsStore = useInstallmentsStore();
const purchase = usePurchaseStore();
const payment = usePaymentStore();
const checkoutV2 = useCheckoutV2Store();

const { method, installments, max_installments, hasFees, fixed_installments, bump_list } =
  storeToRefs(checkout);
const { getInstallments } = storeToRefs(installmentsStore);
const { first } = storeToRefs(purchase);
const { hasSent } = storeToRefs(payment);

const currentYear = new Date().getFullYear();

const expirationYears = computed(() => {
  const years = [];
  for (let i = 0; i < 10; i++) {
    years.push(currentYear + i);
  }
  return years;
});


const isCardValid = ref(true);
const creditCard = ref(null);
const isOnFocus = ref("");


function flipCard(value) {
  onFocus(value ? "cvv" : "");
}

function onFocus(value) {
  isOnFocus.value = value;
}

async function onBlur(value) {
  if (value === "holder_name") {
    onFocus("");
  }
  if (value === "cvv") {
    flipCard(false);
  }
  await validateThristStep();
}

function formatCardNumber(event) {
  let value = event.target.value.replace(/\D/g, "");
  value = value.replace(/(.{4})/g, "$1 ").trim();
  first.value.number = value;
}

function formatAmountText(installments = 1) {
  const { hasFees } = useProductStore();
  const { getInstallmentsTickets } = useInstallmentsStore();
  const { amount } = useAmountStore();

  const getAmount = !hasFees ? getInstallmentsTickets(amount, installments) : getInstallments.value(installments);
  return formatMoney(getAmount);
}

const minInstallments = computed(() => {
  if (Array.isArray(bump_list?.value) && bump_list.value.length > 0) {
    const checkedBumps = bump_list.value.filter(bump => bump.checkbox);
    if (checkedBumps.length > 0) {
      const bumpsMaxInstallments = checkedBumps.map(bump =>  Number(bump.max_installments) || Number(bump.max_subscription_installments) || 12);
      const maxInstallmentsValue = Number(max_installments.value);
      const minInstallmentsValue = Math.min(maxInstallmentsValue, ...bumpsMaxInstallments);
      return minInstallmentsValue;
    }
  }

  return max_installments.value;
});

function setInitialPaymentData() {
  const initialInstallments = installments.value || 12;
  updatePaymentData(initialInstallments);
}

function updatePaymentData(selectedInstallments) {
  const installmentAmount = formatAmountText(Number(selectedInstallments));
  checkoutV2.setPaymentData(Number(selectedInstallments), installmentAmount);
  purchase.setCardsAmount();
}


watch(installments, (newInstallments) => {
  const selectedInstallments = Number(newInstallments);
  const installmentAmount = formatAmountText(selectedInstallments);
  checkoutV2.setPaymentData(selectedInstallments, installmentAmount);
  purchase.setCardsAmount();
});

onMounted(() => {
  setInitialPaymentData();
  checkout.setMethod('CREDIT_CARD');
});
</script>

<style lang="scss" scoped>
.button {
  &:hover {
    background-color: rgba(65, 137, 230, 0.2) !important;
  }
}

.active {
  background-color: rgba(65, 137, 230, 0.2) !important;
  border: 2px solid rgba(65, 137, 230, 0.2);
}

.credit-card-form {
  padding-top: 20px;
}

.form-text {
  color: #003B36;
}

.input-text {
  color: #003B36;
  height: 51px;
}

.form-section {
  margin-top: 1.25rem;
}

label {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #999E9D;
}

input,
select {
  font-family: 'Plus Jakarta Sans', sans-serif;
  width: 100%;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #ddd;
  border-radius: 4px;
  height: 51px;
}

::v-deep(input::placeholder),
::v-deep(select::placeholder) {
  color: #999E9D !important;
}

.input-select {
  color: #003B36;

  &.placeholder-active {
    color: #999E9D;
  }
}

input::placeholder {
  color: #aaa;
}

.expiration {
  display: flex;
  gap: 8px;
  color: #003B36;
}

.expiration-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.expiration-wrapper select {
  width: 100%;
}

.expiration-wrapper label {
  margin-bottom: 0.5rem;
}

.error-message {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 11px;
  font-weight: 400;
  line-height: 13.86px;
  color: #d9534f;
}

.installments {
  margin-bottom: -15px;
}

.input-text:focus {
  outline: none;
  border-color: #00B07F;
}

.input-select:focus {
  outline: none;
  border-color: #00B07F;
}
</style>
