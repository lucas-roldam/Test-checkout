<template>
  <section class="form-section flex flex-col gap-5">
    <label for="document-number"> {{ documentText.label }}</label>
    <div class="flex flex-col gap-2">
      <input
        v-model="document"
        class="input-text"
        type="text"
        input-name="document-field"
        input-id="document-field"
        :placeholder="documentText.placeholder"
        @input="applyMask"
        @blur="allBlurInputEvent()"
        :class="{ 'input-error': hasError && document}"
      />
      <span class="document-info">
        Para emissão de boleto, necessário CPF/CNPJ
      </span>
      <span
        v-if="hasError && document"
        class="error-message"
      >
        {{ $t("checkout.dados_pessoais.feedbacks.document") }}
      </span>
    </div>
  </section>
</template>

<script setup>
import { onMounted, computed } from "vue";
// Stores
import { usePersonalStore } from "@/store/forms/personal";
import { useLeadsStore } from "@/store/modules/leads";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
// Validation
import {
  validateFirstStep,
  validateDocument,
  validateRequired,
} from "@/rules/form-validations";

/* Variables */
const currentCountry = useState("currentCountry");
const personalStore = usePersonalStore();
const leadsStore = useLeadsStore();
const checkoutV2 = useCheckoutV2Store();

const { document, forceDocument } = storeToRefs(personalStore);

async function allBlurInputEvent(isEmail = false) {
  checkoutV2.setHasError(hasError)
  setTimeout(function () {
    leadsStore.updateLead();
  }, 1000);
}

function applyMask(event) {
  const mask = documentText.value.documentMask;
  let value = event.target.value.replace(/\D/g, ""); 

  let maskedValue = "";
  let maskIndex = 0;

  for (let i = 0; i < value.length; i++) {
    if (maskIndex >= mask.length) break;

    if (mask[maskIndex] === "#") {
      maskedValue += value[i];
      maskIndex++;
    } else {
      maskedValue += mask[maskIndex];
      maskIndex++;
      i--;
    }
  }

  document.value = maskedValue;
}

const hasError = computed(() => {
  if (document.value.length === 0) return true;
  if (!document.value) return false;
  if (currentCountry.value === "BR") return !validateDocument.isValidSync(document.value);
  return !validateRequired.isValidSync(document.value);
});

const documentText = computed(() => {
  const cleanValue = document.value.replace(/[^\d]/g, "");
  switch (currentCountry.value) {
    case "AR":
      return {
        label: "CUIT/CUIL o DNI",
        placeholder: "CUIT/CUIL o DNI",
        documentMask: "#####################",
      };
    case "MX":
      return {
        label: "Número RFC",
        placeholder: "Número RFC",
        documentMask: "########################",
      };
    case "UY":
      return {
        label: "Número CI",
        placeholder: "Número CI",
        documentMask: "########################",
      };
    case "CL":
      return {
        label: "Añadir RUT",
        placeholder: "Añadir RUT",
        documentMask: "#####################",
      };
    default:
      return {
        label: "CPF/CNPJ",
        placeholder: "Doc. do titular da compra",
        documentMask:
          cleanValue.length === 11 ? "###.###.###-##" : "##.###.###/####-##",
      };
  }
});
onMounted(() => {
  checkoutV2.setHasError(hasError)
});
</script>

<style lang="scss" scoped>
.form-section {
  margin-top: 1.25rem;
}

label {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #999E9D;
}

.document-info {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 11px;
  font-weight: 400;
  line-height: 13.86px;
  color: #999E9D;
}

input {
  font-family: 'Plus Jakarta Sans', sans-serif;
  width: 100%;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #ddd;
  border-radius: 4px;
  height: 51px;
}

.input-text {
  color: #003B36;
}

.input-error {
  border-color: #d9534f !important;
}

::v-deep(input::placeholder) {
  color: #999E9D !important;
}

input::placeholder {
  color: #aaa;
}

.error-message {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 11px;
  font-weight: 400;
  line-height: 13.86px;
  color: #d9534f;
}

.input-text:focus {
  outline: none;
  border-color: #00B07F;
}
</style>
