<template>
  <section class="mb-[24px] ml-4 mr-2 flex items-center justify-center">
    <div
      v-for="(benefit, index) in benefits"
      :key="index"
      class="flex flex-col items-center justify-center gap-4"
    >
      <img
        :src="benefit.icon"
        :alt="benefit.title"
      />
      <div>
        <h3 class="benefits-title">{{ benefit.title }} </h3>
      </div>
    </div>
  </section>

  <section class="flex w-full flex-wrap items-center justify-center md:justify-between">
    
    <span class="flex flex-wrap items-center justify-center mb-[24px]" style="filter: grayscale(1); opacity: 0.7">
      <img :src="Greenn" alt="logo do greenn" />
    </span>
    <span class="flex flex-wrap items-center justify-center gap-4 mb-[24px]" style="filter: grayscale(1); opacity: 0.7">
      <img
        v-for="(img, index) in imgs"
        :src="img.src"
        :alt="img.alt"
        :key="index"
      />
    </span>
  </section>
  <div class="text-disclaimer-size text-gray-400 px-4">
    <p>
      {{t("disclaimer.ao_concluir")}}
      <a
        href="https://greenn.com.br/termos-de-uso-greenn/"
        target="_blank"
        rel="noopener noreferrer"
        class="text-green-600 underline hover:text-green-800"
      >
      {{t("disclaimer.termos_de_uso")}}
      </a>
      {{t("disclaimer.e")}}
      <a
        href="https://greenn.com.br/politicas-e-termos-greenn"
        target="_blank"
        rel="noopener noreferrer"
        class="text-green-600 underline hover:text-green-800"
      >
      {{t("disclaimer.demais_politicas")}}
      </a>
      {{t("disclaimer.plataforma_dados")}}
    </p>
    <p class="mt-2">
      {{t("disclaimer.responsabilidade_da_oferta")}}
      <strong class="font-medium">{{
            product.seller.company
              ? product.seller.company.fantasy_name || product.seller.company.name
              : product.seller.name
          }}</strong>{{t("disclaimer.realiza_venda_plataforma")}}
    </p>
  </div>
  <footer
    class="flex mb-[140px] min-h-[45px] w-full flex-col items-center justify-center gap-2 p-4 md:items-center"
  >
    <p
      v-if="installments_fee"
      class="checkout-footer-grenn relative flex flex-nowrap text-[10px] text-txt-color md:hidden"
    >
      {{ $t("components.footer.annual_fee") }}
    </p>
    <p class="checkout-footer-grenn text-[10px] text-txt-color">
      Greenn © {{ actual_year }} - {{ $t("components.footer.reverved_text") }}
    </p>
  </footer>
</template>

<script setup>
import { computed } from 'vue';
// Icons
import PciIcon from "@/assets/checkoutV2/footer/pci.svg";
import VisaIcon from "@/assets/checkoutV2/footer/visa.svg";
import MastercardIcon from "@/assets/checkoutV2/footer/mastercard.svg";
import HipercardIcon from "@/assets/checkoutV2/footer/hipercard.svg";
import EloIcon from "@/assets/checkoutV2/footer/elo.svg";
import Greenn from "@/assets/checkoutV2/footer/greenn.svg";
import SecureIcon from "@/assets/checkoutV2/benefits/secure.svg";
import ReviewedIcon from "@/assets/checkoutV2/benefits/reviewed.svg";
import ProtectedIcon from "@/assets/checkoutV2/benefits/protected.svg";
const productStore = useProductStore();
const { product } = storeToRefs(productStore);

const actual_year = computed(() => new Date().getFullYear());
const { t } = useI18n();
const props = defineProps({
  installments_fee: {
    required: false,
    type: Boolean,
    default: true,
  },
});

const imgs = [
  {
    src: PciIcon,
    alt: "Pci icon",
  },
  {
    src: MastercardIcon,
    alt: "Mastercard icon",
  },
  {
    src: VisaIcon,
    alt: "Visa icon",
  },
  {
    src: EloIcon,
    alt: "Elo icon",
  },
  {
    src: HipercardIcon,
    alt: "Hipercard-v2 icon",
  },
];

const benefits = [
  {
    icon: SecureIcon,
    title: "Compra segura",
  },
  {
    icon: ReviewedIcon,
    title: "Produto revisado",
  },
  {
    icon: ProtectedIcon,
    title: "Dados protegidos",
  },
];
</script>

<style scoped>
.benefits-title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 11px;
  font-weight: 400;
  line-height: 16.38px;
  color: #666D6D;
  margin-right: 14px;
  margin-left: 14px;
}

.checkout-footer-grenn {
  font-family: 'Plus Jakarta Sans', sans-serif;
  color: #999E9D;
}

.text-disclaimer-size {
  font-size: 10px;
}
</style>
