<template>
  <header class="header top-0 z-50 flex min-h-[60px] w-full items-center justify-between bg-white px-4">
    <a href="https://greenn.com.br/" target="_blank">
      <img
        :src="greenn"
        alt="Logo da pagina"
        class="max-h-10 max-w-[100px] object-contain"
        width="100"
        height="40"
      />
    </a>
    <div class="buy-secure">
      <img :src="secure"/>
      <span class="font-secure">Compra segura</span>
    </div>
  </header>
  <header class="flex-direction-column max-h-[45vh] w-full max-w-[1250px] items-left">
    <div class="title">Olá, {{ firstName }} 👋</div>
    <div class="subtitle">Vamos concluir sua compra!</div>
  </header>
</template>

<script setup>
import { useStepStore } from "~~/store/modules/steps";
import { usePersonalStore } from "~~/store/forms/personal";
import greenn from "@/assets/checkoutV2/header/greenn.svg";
import secure from "@/assets/checkoutV2/header/secure.svg";

const stepStore = useStepStore();
const personalStore = usePersonalStore();

const { name } = storeToRefs(personalStore);

const firstName = String(name.value || "").split(" ")[0];

const nameComputed = computed(() => {
  return name.value
});

onMounted(async() => {
  await stepStore.setMobileV2();
  stepStore.initializeStep();
});
</script>

<style lang="scss" scoped>
.header {
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}
.title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 18px;
  font-weight: 800;
  line-height: 22.68px;
  text-align: left;
  text-underline-position: from-font;
  text-decoration-skip-ink: none;
  margin: 48px 0px 12px 24px;
  color: #003B36;
}
.subtitle {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  text-align: left;
  text-underline-position: from-font;
  text-decoration-skip-ink: none;
  margin: 0px 0px 32px 24px;
  color: #999E9D;
}
.buy-secure {
  font-family: 'Plus Jakarta Sans', sans-serif;
  display: flex;
  gap: 8px;
  background-color: #EBFEF6;
  color: #007C5D;
  padding: 8px 16px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  line-height: 15.12px;
}
.font-secure {
  font-family: 'Plus Jakarta Sans', sans-serif;
}
</style>
