<template  v-if="isLogoValidated && isMobileResponsive">
  <div class="purchase-processing">
    <div class="purchase-info">
      <p class="title">Total da compra</p>
      <p v-if="checkoutV2.method === 'credit_card'" class="value">{{formatMoney(purchase.first.amount)}}</p>
      <p v-else class="value">{{formatMoney(amountStore.getAmount)}}</p>
    </div>
    <div class="loader-wrapper">
      <div class="circular-loader">
        <div class="circle"></div>
      </div>
    </div>
    <div>
      <p class="text-subtitle-1">Processando compra...</p>
      <p class="text-subtitle-2">Não saia desta tela, sua compra está sendo processada. Aguarde um momento.</p>
    </div>
    <div class="security">
      <div class="security-icon">
        <svg width="32" height="34" viewBox="0 0 32 34" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="32" height="33.3333" rx="16" fill="#EBFEF6"/>
        <path d="M12.6667 16V13.3333C12.6667 12.4493 13.0179 11.6014 13.643 10.9763C14.2681 10.3512 15.1159 10 16 10C16.8841 10 17.7319 10.3512 18.357 10.9763C18.9821 11.6014 19.3333 12.4493 19.3333 13.3333V16M11.3333 16H20.6667C21.403 16 22 16.597 22 17.3333V22C22 22.7364 21.403 23.3333 20.6667 23.3333H11.3333C10.597 23.3333 10 22.7364 10 22V17.3333C10 16.597 10.597 16 11.3333 16Z" stroke="#00B07F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="text-icon">Compra segura</span>
      </div>
    </div>
    <div class="logo">
        <img :src="logo_gray"/>
    </div>
  </div>
</template>

<script setup>
// Stores
import { useStepStore } from "~~/store/modules/steps";
import { useAmountStore } from  "~~/store/modules/amount";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
// Utils
import { formatMoney } from "~~/utils/money";
// Icons
import logo_gray from "@/assets/icons/logo_gray.svg";


const purchase = usePurchaseStore();
const checkoutV2 = useCheckoutV2Store();
const amountStore = useAmountStore();
const stepStore = useStepStore();
const { isMobileResponsive } = storeToRefs(stepStore);
</script>

<style scoped>
.purchase-processing {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-family: 'Arial', sans-serif;
  text-align: center;
  background-color: #ffffff;
  color: #333;
  padding-left: 24px;
  padding-right: 24px;
}

.loader-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 48px;
}

.circular-loader {
  position: relative;
  width: 300px;
  height: 300px;
  border:  5px solid #f0f0f0;
  border-top: 5px solid #38b58f;
  border-radius: 50%;
  animation: spin 2s linear infinite;
  display: flex;
  align-items: center;
  justify-content: center;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.purchase-info {
  position: relative;
  top:  12rem;
}

.title {
  color: #999E9D;
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 16px;
  font-style: normal;
  line-height: normal;
  margin-bottom: 16px;
}

.value {
  color: #003B36;
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 32px;
  font-style: normal;
  font-weight: 900;
  line-height: normal;
}

.security {
  margin-top: 80px;
  display: flex;
  align-items: center;
}

.security-icon {
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #38b58f;
}

.security-icon img {
  width: 20px;
  height: 20px;
  margin-right: 8px;
}

.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 80px;
}

.logo img {
  width: 100px;
  height: auto;
}

.text-icon{
  margin-left: 1rem;
  color: #999E9D;
  font-family: "Plus Jakarta Sans";
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}

.text-subtitle-1{
    color: #003B36;
    text-align: center;
    font-feature-settings: 'liga' off, 'clig' off;
    font-family: "Plus Jakarta Sans";
    font-size: 18px;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
    margin-bottom: 32px;
}

.text-subtitle-2{
  color: #999E9D;
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: 150%;
}
</style>