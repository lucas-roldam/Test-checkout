<template>
  <div class="discount-options">
    <p class="discount-options__title">
      Você desbloqueou descontos <span class="emoji">🤑</span>
    </p>
    <div class="discount-options__items">
      <div 
        v-for="(item, index) in bump_list" 
        :key="index"
        class="discount-options__item" 
        @click="setOrderBump(item)"
      >
        <div class="discount-options__bumps">
          <div class="discount-options__checkbox">
            <input
              type="checkbox"
              :id="`item-${index}`"
              v-model="item.selected"
              @click="setOrderBump(item)"
            />
            <label :for="`item-${index}`"></label>
          </div>
          <div class="discount-options__content">
            <div class="discount-options__details">
              <img :src="item.images[0].path" :alt="item.name" class="image" />
              <div>
                <p class="discount-options__subtitle">{{ item.name }}</p>
              </div>
            </div>
          </div>
          <p class="discount-options__price">{{ formatMoney(item.amount) }}</p>
        </div>
        <div class="discount-options_markdown">
          <div
            :class="{'truncated': !expanded[index]}"
          >
            <MdPreview
              :modelValue="item.description"
              previewOnly
            />
          </div>
          <span
            v-if="item.description.length > 100"
            @click.stop="toggleDescription(index)"
            class="toggle-link"
          >
            {{ expanded[index] ? 'Ver menos' : 'Ver mais' }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { MdPreview } from 'md-editor-v3';
// Utils
import { formatMoney } from "~~/utils/money";
// Stores
import { useCheckoutStore } from "@/store/checkout";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
import { useInstallmentsStore } from "~~/store/modules/installments";
import { useAmountStore } from  "~~/store/modules/amount";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useProductStore } from "~~/store/product";

const purchase = usePurchaseStore();
const installmentsStore = useInstallmentsStore();
const checkoutV2 = useCheckoutV2Store();
const checkout = useCheckoutStore();
const productStore = useProductStore();

const { getInstallments } = storeToRefs(installmentsStore);
const { bump_list } = storeToRefs(checkout);
const { contract_terms} = storeToRefs(productStore);

const expanded = ref([]);

const formattedMarkdown = computed(() => {
  return contract_terms.value.body.replace(/\\/g, '\n')
});

const toggleDescription = (index) => {
  expanded.value[index] = !expanded.value[index];
};

const truncatedDescription = (description) => {
  return description.length > 100
    ? description.slice(0, 100) + '...'
    : description;
};

function formatAmountText(installments = 1) {
  const { hasFees } = useProductStore();
  const { getInstallmentsTickets } = useInstallmentsStore();
  const { amount } = useAmountStore();

  const getAmount = !hasFees ? getInstallmentsTickets(amount, installments) : getInstallments.value(installments);
  return formatMoney(getAmount);
}

function setOrderBump(item) {
  item.selected = !item.selected;
  checkout.setProductList(item)

  const installment = checkoutV2.installment

  const installmentAmount = formatAmountText(Number(installment));
  checkoutV2.setPaymentData(Number(installment), installmentAmount);
  purchase.setCardsAmount();
}
</script>

<style lang="scss" scoped>
.discount-options__title {
  font-family: Plus Jakarta Sans;
  font-size: 14px;
  font-weight: 700;
  line-height: 17.64px;
  color: #003B36;
  margin-bottom: 16px;
}

.discount-options__items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
  cursor: pointer;
}

.discount-options__bumps {
  display: flex;
  cursor: pointer;
  margin-bottom: 25px;
  align-items: center;
}

.discount-options__item {
  font-family: 'Plus Jakarta Sans', sans-serif;
  display: flex;
  padding: 15px;
  margin-bottom: 10px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  flex-direction: column;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.discount-options__checkbox {
  margin-right: 1rem;
  margin-top: 8px;

  input[type='checkbox'] {
    display: none;
  }

  label {
    font-family: Plus Jakarta Sans;
    border-radius: 2px;
    border: 1px solid #CCCECE;
    display: inline-block;
    width: 14px;
    height: 14px;
    position: relative;
    transition: background-color 0.3s ease, border-color 0.3s ease;
    width: 15px;
    height: 15px;
    transform: scale(1.2);
    cursor: pointer;

    &:after {
      content: '✓';
      font-family: Plus Jakarta Sans;
      position: absolute;
      top: 50%;
      left: 50%;
      font-size: 1rem;
      color: #FFFFFF;
      transform: translate(-50%, -50%);
      transition: opacity 0.3s ease;
    }
  }

  input:checked + label {
    background-color: #00B07F;
    border-color: #00B07F;
  }
}

.discount-options__content {
  flex-grow: 1;

  &__details {
    display: flex;
    align-items: center;

    img {
      width: 3rem;
      height: 3rem;
      margin-right: 1rem;
      border-radius: 50%;
    }

    p {
      margin: 0;
      font-size: 0.9rem;
    }
  }
}

.discount-options__details {
  display: flex;
  align-items: center;
  gap: 12px;
}

.image {
  width: 35px;
  height: 35px;
  border-radius: 50%;
}

.discount-options__subtitle {
  font-family: Plus Jakarta Sans;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
}

.discount-options__description {
  font-family: Plus Jakarta Sans;
  font-size: 14px;
  font-weight: 400;
  line-height: 19.6px;
  word-break: break-word;
  color: #999E9D;
  transition: max-height 0.3s ease;
}

.discount-options__price {
  font-family: Plus Jakarta Sans;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
  white-space: nowrap;
  margin-top: 8px;
}

.discount-options_markdown {
  position: relative;

  .truncated {
    max-height: 60px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
}

.toggle-link {
  font-family: Plus Jakarta Sans;
  cursor: pointer;
  font-size: 12px;
  font-weight: 400;
  color: #00B07F;
  margin-top: 8px;
  display: inline-block;
}
</style>
