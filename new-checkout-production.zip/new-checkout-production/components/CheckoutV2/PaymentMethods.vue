<template>
  <section>
    <h2 class="title">Métodos de pagamento</h2> 
    <div 
      v-for="(method, index) in paymentMethods" 
      :key="method.id" 
      :class="[
        'payment-method', 
        `payment-method--${method.id}`, 
        { selected: selectedMethod === method.id }
      ]" 
      @click="selectMethod(method.id, method.button)"
    >
      <div
        :class="{
          'selection-indicator-pix': method.id === 'pix',
          'selection-indicator-boleto': method.id === 'boleto',
          'selection-indicator-credit-card': method.id === 'credit_card'
        }"
      >
        <div 
          class="outer-circle" 
          :class="{ 'selected-circle': selectedMethod === method.id }"
        >
          <div 
            v-if="selectedMethod === method.id" 
            class="inner-circle"
          ></div>
        </div>
        <div>
          <span v-if="method.recommended" class="recommended-badge">Recomendado</span>
        </div>
      </div>
      <div class="card-info">
        <div class="method-info">
          <img :src="method.icon" :alt="method.title" class="icon" />
          <div>
            <h3 class="method-title">{{ method.title }}</h3>
            <p class="method-description">{{ method.description }}</p>
          </div>
        </div>

        <div v-if="method.id === 'credit_card' && selectedMethod === 'credit_card'">
          <CheckoutV2CreditCard> </CheckoutV2CreditCard>
        </div>
        <div v-if="method.id === 'boleto' && selectedMethod === 'boleto'">
          <CheckoutV2Document> </CheckoutV2Document>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
// Icons
import PixIcon from "@/assets/checkoutV2/paymentMethods/pix.svg";
import CreditCardIcon from "@/assets/checkoutV2/paymentMethods/creditCard.svg";
import BoletoIcon from "@/assets/checkoutV2/paymentMethods/boleto.svg";
// Stores
import { useCheckoutV2Store } from "~~/store/modules/checkoutV2";
import { useCheckoutStore } from "~~/store/checkout";

const checkoutV2Store = useCheckoutV2Store();
const checkoutStore = useCheckoutStore();

const { allowed_methods } = storeToRefs(checkoutStore);

const paymentMethods = computed(() => {
  const validMethods = ["CREDIT_CARD", "BOLETO", "PIX"];
  const methods = allowed_methods.value
    .filter((item) => validMethods.includes(item))
    .map((item) => {
      switch (item) {
        case "CREDIT_CARD":
          return {
            id: "credit_card",
            title: "Cartão de crédito",
            button: "Cartão",
            description: "Parcele em até 12x",
            recommended: false,
            icon: CreditCardIcon,
          };
        case "BOLETO":
          return {
            id: "boleto",
            title: "Boleto",
            button: "Boleto",
            description: "Vencimento em até 3 dias",
            recommended: false,
            icon: BoletoIcon,
          };
        case "PIX":
          return {
            id: "pix",
            title: "Pix",
            button: "Pix",
            description: "Aprovação imediata",
            recommended: false,
            icon: PixIcon,
          };
        default:
          return null;
      }
    });

  const priorities = { pix: 1, credit_card: 2, boleto: 3 };
  const sortedMethods = methods.sort((a, b) => priorities[a.id] - priorities[b.id]);

  if (sortedMethods.length > 0) {
    sortedMethods[0].recommended = true;
  }

  return sortedMethods;
});

const selectedMethod = ref(null);

const selectMethod = (id, button) => {
  selectedMethod.value = id;
  checkoutV2Store.setMethod(id, button);
  if (id !== "credit_card") {
    checkoutStore.setMethod(id.toUpperCase());
  }
  checkoutV2Store.setPaymentIsDisabled();
};

onMounted(() => {
  const firstMethod = paymentMethods.value[0];
  if (firstMethod) {
    selectedMethod.value = firstMethod.id;
    checkoutV2Store.setMethod(firstMethod.id, firstMethod.button);
    checkoutStore.setMethod(firstMethod.id.toUpperCase());
  }
});
</script>

<style scoped>
.title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 700;
  line-height: 17.64px;
  margin-bottom: 16px;
  color: #003B36;
}

.payment-method--pix {
  display: flex;
  padding: 15px;
  margin-bottom: 10px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  flex-direction: row-reverse;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.payment-method--credit_card {
  display: flex;
  padding: 15px;
  margin-bottom: 10px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  flex-direction: row-reverse;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.payment-method--boleto {
  display: flex;
  padding: 15px;
  margin-bottom: 10px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  flex-direction: row-reverse;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.payment-method:hover {
  border-color: #00B07F;
}

.payment-method.selected {
  border-color: #00B07F;
}

.method-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.card-info {
  flex-grow: 1;
}

.icon {
  width: 45px;
  height: 45px;
}

.method-title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
  margin-bottom: 8px;
}

.method-description {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #999E9D;
}

.recommended-badge {
  font-family: 'Plus Jakarta Sans', sans-serif;
  background-color: #EBFEF6;
  color: #00B07F;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  line-height: 15.12px;
}

.selection-indicator-pix {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  margin-left: auto;
  gap: 6px;
  flex-shrink: 0;
}

.selection-indicator-boleto {
  display: flex;
  flex-shrink: 0;
  flex-direction: row-reverse;
  position: absolute;
  gap: 5px;
  align-items: center;
}

.selection-indicator-credit-card {
  display: flex;
  margin-left: auto;
  gap: 6px;
  flex-shrink: 0;
  position: absolute;
  align-items: flex-end;
  flex-direction: column;
}

.outer-circle {
  width: 16px;
  height: 16px;
  border: 2px solid #E5E7E7;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: border-color 0.2s;
}

.outer-circle.selected-circle {
  border-color: #00B07F;
}

.outer-circle .inner-circle {
  width: 8px;
  height: 8px;
  background-color: #00B07F;
  border-radius: 50%;
}
</style>
