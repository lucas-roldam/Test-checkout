<template>
  <div class="pix-container">
    <p class="title">Copie este código para pagar</p>
    <div class="instructions">
      <div class="instructions-item mt-24">
        <img :src="circle_number_1"/>
        <p>Abra o aplicativo do seu banco</p>
      </div>
      <div class="instructions-item mt-24">
        <img :src="circle_number_2"/>
        <p>Escolha pagar via {{map.get(paymentMethod)}}</p>
      </div>
      <div class="instructions-item mt-24">
        <img :src="circle_number_3"/>
        <p>Cole o código e finalize o pagamento</p>
      </div>
    </div>
    <p class="subtitle-code">{{ 'Código '+(paymentMethod == 'PIX' ? 'Pix': 'de barras' ) }}</p>

    <div class="pix-code" id="code">
      <span class="pix-code-text">{{ code }}</span>
    </div>

    <div v-if="paymentMethod == 'PIX'" class="timer mt-24">
      Código expira em: 
      <span class="text-cron">{{timerText}}</span>
    </div>
    <div class="pix-code-container mt-24">
      <button 
        class="btn-copy"
        :class="{ 'btn-copied': copied }" 
        @click="copyCode"
      >
      <svg 
        v-if="copied" 
        width="15" 
        height="10" 
        viewBox="0 0 15 10" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <path 
          d="M13.5 0.875L5.25 9.125L1.5 5.375" 
          stroke="white" 
          stroke-width="1.5" 
          stroke-linecap="round" 
          stroke-linejoin="round"
        />
      </svg>
      {{ copied ? 'Código '+(paymentMethod == 'PIX' ? 'Pix': 'de barras' )+' copiado' : 'Copiar código ' + (paymentMethod == 'PIX' ? 'Pix': 'de barras' ) }} 
      
      </button>
    </div>

    <p class="footer-text mt-24">{{ paymentMethod == 'PIX' ? 'Pague agora e receba o seu produto' : 'Pague o boleto em até 2 dias úteis'  }}</p>
    <div class="confirmation mt-24">
      <a href="#" @click.prevent="paymentMethod == 'PIX' ? confirmPayment() : printBoleto()">
          {{ paymentMethod == 'PIX' ? 'Já realizei o pagamento' : 'Imprimir boleto '  }}
        </a>
    </div>
  </div>
</template>

<script lang="ts">
import circle_number_1 from "@/assets/icons/circle_number_1.svg";
import circle_number_2 from "@/assets/icons/circle_number_2.svg";
import circle_number_3 from "@/assets/icons/circle_number_3.svg";
import { useCheckoutStore } from "~~/store/checkout";
import { type Sale } from "@/types";

export default {
  data() {
    const checkoutStore = useCheckoutStore();

    const map = new Map([
      ['PIX', 'Pix'],
      ['BOLETO', 'Boleto'],
      ['CREDIT_CARD', 'Cartão de Crédito']
    ]);

    const route: any = useRoute();
    const queryKeys = Object.keys(route.query);
    const isEvent = queryKeys.some(x => x.includes('ticket_id'));

    const saleId = isEvent
        ? route.query.s_id ? route.query.s_id : route.query[queryKeys[0]].split("-s_id_")[1]
        : route.query.s_id;

    const paymentMethod = computed(() => checkoutStore.method);
    const sucessPayment = computed(() => checkoutStore.sucessPayment);

    return {
      code: '',
      boleto_url: 'https://www.greenn.com.br', 
      timerText: '09:59',
      countdown: 600, 
      circle_number_1, 
      circle_number_2,
      circle_number_3,
      map,
      paymentMethod,
      saleId,
      copied: false,
    };
  },
  methods: {
    copyCode() {
      navigator.clipboard
        .writeText(this.code)
        .then(() => {
          this.copied = true;
        })
        .catch(() => {
         
        });
    },
    startCountdown() {
      const interval = setInterval(() => {
        if (this.countdown > 0) {
          this.countdown--;
          const minutes = String(Math.floor(this.countdown / 60)).padStart(2, '0');
          const seconds = String(this.countdown % 60).padStart(2, '0');
          this.timerText = `${minutes}:${seconds}`;
        } else {
          clearInterval(interval);
        }
      }, 1000);
    },
    confirmPayment() {
      const checkoutStore = useCheckoutStore();
      checkoutStore.setSucessPayment(true);
    },
    printBoleto(){
      window.open(this.boleto_url, '_blank');
    },
    async getSale(){
      const checkoutStore = useCheckoutStore();
      let sale = await checkoutStore.getSale(this.saleId);

      if(sale?.order){
        if(sale?.order.qrcode && this.paymentMethod == 'PIX'){
          this.code =  sale.order.qrcode;
        }
        else if(sale?.order.boleto_barcode && this.paymentMethod == 'BOLETO'){
          this.code =  sale.order.boleto_barcode;
          this.boleto_url =  sale.order.boleto_url;
        }
      }
      else{
        if(sale?.sales[0]?.qrcode && this.paymentMethod == 'PIX'){
          this.code =  sale.sales[0].qrcode;
        }
        else if(sale?.sales[0]?.boleto_barcode && this.paymentMethod == 'BOLETO'){
          this.code =  sale.sales[0].boleto_barcode;
          this.boleto_url =  sale.sales[0].boleto_url;
        }
      }
    },
  },
  mounted() {
    this.startCountdown();
    this.getSale();
  },
};
</script>

<style scoped>
body {
  font-family: Arial, sans-serif;
  background-color: #f7f7f7;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  height: 100vh;
}

.title{
  color: #003B36;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
  line-height: 150%;
  margin-bottom: 32px;
}

.pix-container {
  background: #fff;
  border-radius: 8px;
  width: 100%;
}

.instructions {
  text-align: left;
  margin-bottom: 16px;
  color: #333;
  font-size: 14px;
  line-height: 1.5;
}

.instructions strong {
  font-weight: bold;
}

.instructions-item{
  display: flex;
  flex-direction: row;
  align-items: center;
  color: #003B36;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: 150%;
  gap: 1rem;
}

.pix-code-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.pix-code {
  display: flex;
  width: 100%;
  padding: 16px;
  justify-content: space-between;
  align-items: center;
  border-radius: 8px;
  border: 1px solid #E5E7E7;
}

.pix-code-text{
  color: #999E9D;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  white-space: nowrap;
  overflow: hidden; 
  mask-image: linear-gradient(to right, black 90%, transparent);
  -webkit-mask-image: linear-gradient(to right, black 90%, transparent);
}

.btn-copy {
  display: flex;
  width: 100%;
  height: 60px;
  padding: 22px 24px;
  justify-content: center;
  align-items: center;
  gap: 16px;
  border-radius: 8px;
  background: var(--Blue-500, #3886F9);
  color: var(--Gray-White, #FFF);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}

.btn-copied {
  background: #00B07F !important;
}

.timer {
  color: #999E9D;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: 150%; /* 21px */
  justify-content: flex-start;
}
.text-cron{
  color: #2469EE !important;
}

.confirmation {
  display: flex;
  justify-content: center;
}

.confirmation a {
  color: var(--Blue-600, #2469EE);
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  line-height: 150%; /* 24px */
  text-decoration: none;
}

.confirmation a:hover {
  text-decoration: underline;
}

.mt-24{
  margin-top: 24px
}

.footer-text{
  color: #999E9D;
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: 150%; /* 21px */
}

.logo-conteiner{
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 48px;
}

.subtitle-code{
  color: var(--Gray-200, #999E9D);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 13px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  margin-top: 32px;
  margin-bottom: 10px;
}
</style>
