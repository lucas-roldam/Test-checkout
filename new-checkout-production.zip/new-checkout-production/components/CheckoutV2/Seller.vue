<template>
  <section class="min-h-[60px] w-full">
    <h2 class="title">Vendedor</h2> 
    <div class="seller-card">
      <div>
        <div class="seller-primary">
          <img :src="sellerSvg" alt="seller" class="icon" />
          <div>
            <h3 class="seller-title">
              {{ nameComputed }}
            </h3>
            <p class="seller-description">Vendedor Greenn desde {{ formatDateToMonthYear(product.product.seller.created_at) }}</p>
          </div>
        </div>
        <hr class="separator" />
        <div class="seller-info-container">
          <h3
            v-if="!isTextTooLong && phoneComputed && emailComputed"
            class="seller-info"
          >
            {{ emailComputed }} · {{ formatPhoneNumber(phoneComputed) }}
          </h3>
          <h3 v-else-if="isTextTooLong" class="seller-info">
            {{ emailComputed }}
            <br/>
            {{ formatPhoneNumber(phoneComputed) }}
          </h3>
          <h3 v-else-if="!phoneComputed" class="seller-info">
            {{ emailComputed }}
          </h3>
          <h3 v-else-if="!emailComputed" class="seller-info">
            {{ formatPhoneNumber(phoneComputed) }}
          </h3>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
//Stores
import { useProductStore } from "~~/store/product";
import sellerSvg from "@/assets/checkoutV2/seller/seller.svg";
import { computed } from 'vue';

const product = useProductStore();

const emailComputed = computed(() => {
  return product?.product?.seller?.company?.email || "";
});

const phoneComputed = computed(() => {
  return product?.product?.seller?.company?.support_telephone || "";
});

const nameComputed = computed(() => {
  const company = product?.product?.seller?.company;
  return company?.fantasy_name || company?.name || product?.product?.seller?.name || "";
});

const formatPhoneNumber = (phone) => {
  if (!phone) return "";

  const cleanedPhone = phone.replace(/^\+55/, "");

  const ddd = cleanedPhone.slice(0, 2);
  const number = cleanedPhone.slice(2);

  if (number.length === 8) {
    return `(${ddd}) ${number.slice(0, 4)}-${number.slice(4)}`;
  }
  if (number.length === 9) {
    return `(${ddd}) ${number.slice(0, 5)}-${number.slice(5)}`;
  }

  return "Número inválido";
};

function formatDateToMonthYear(dateString) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR', { month: 'short', year: 'numeric' })
    .format(date)
    .replace('.', '')
    .replace(/\b(\w+)/, (match) => `${match}`);  
}

const isTextTooLong = computed(() => {
  return (emailComputed?.value?.length + phoneComputed?.value?.length) > 39;
});
</script>

<style scoped>
.title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 700;
  line-height: 17.64px;
  margin-bottom: 17px;
  color: #003B36;
}

.seller-card {
  font-family: 'Plus Jakarta Sans', sans-serif;
  padding: 15px;
  margin-bottom: 10px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.seller-primary {
  display: flex;
  align-items: center;
  gap: 10px;
}

.seller-title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
  margin-bottom: 10px;
}

.seller-description {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 16.38px;
  color: #999E9D;
}

.icon {
  width: 45px;
  height: 45px;
}

.separator {
  border: none;
  border-top: 1px solid #E5E7E7;
  margin: 10px 0;
  width: 100%;
}

.seller-info-container {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.seller-info {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: #003B36;
  white-space: normal;
  word-break: break-word;
}
</style>
