<template>
  <p class="title">Olá, {{personalStore.name.split(' ')[0]}}  👋</p>
  <p class="subtitle">Seu produto foi enviado por e-mail após a aprovação da compra. Não se esqueça de verificar a caixa de SPAM.</p>
  <div class="title-card-item">Produto</div>
  <div class="content-item">
   <!--  product.product.images[0]?.path -->
    <img class="img-product" :src="product.product.images[0]?.path"/>
    <div class="conteiner-item">
      <p class="title-item"> {{product.product.name}} </p>
      <p class="subtitle-item">{{ formatTranslation() }}</p>
    </div>
  </div>
  <div class="title-card-item">Vendedor</div>
  <div class="content-item item-seller">
    <div class="sub-item">
      <img :src="sellerIcon"/>
      <div class="conteiner-item">
        <p class="title-item">
          {{ nameComputed }}
        </p>
        <p class="subtitle-item-mini">Vendedor Greenn desde {{ formatDateToMonthYear(product.product.seller.created_at) }}</p>
      </div>
    </div>
    <hr class="separator" />
    <div class="seller-info-container">
      <h3
        v-if="!isTextTooLong && phoneComputed && emailComputed"
        class="seller-info"
      >
        {{ emailComputed }} · {{ formatPhoneNumber(phoneComputed) }}
      </h3>
      <h3 v-else-if="isTextTooLong" class="seller-info">
        {{ emailComputed }}
        <br/>
        {{ formatPhoneNumber(phoneComputed) }}
      </h3>
      <h3 v-else-if="!phoneComputed" class="seller-info">
        {{ emailComputed }}
      </h3>
      <h3 v-else-if="!emailComputed" class="seller-info">
        {{ formatPhoneNumber(phoneComputed) }}
      </h3>
    </div>
  </div>
  <div class="title-card-item">Detalhes do pagamento</div>
  <div class="content-item">
    <img :src="mapIcons.get(paymentMethod)"/>
      <div class="conteiner-item">
        <p v-if="methodv2 === 'credit_card'" class="title-item"> {{formatMoney(amountCredidCard)}} </p>
        <p v-else class="title-item"> {{formatMoney(amountStore.getAmount)}} </p>
        <p class="subtitle-item"> {{map.get(paymentMethod)}}  ·  {{currentDateFormatted}} |  #{{ saleId }}</p>
      </div>
  </div>
  <div class="logo-conteiner">
  </div>
</template>

<script lang="ts">
// Stores
import { useCheckoutStore } from "~~/store/checkout";
import { useProductStore } from "~~/store/product";
import { useAmountStore } from  "~~/store/modules/amount";
import { usePersonalStore } from "@/store/forms/personal";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
// Icons
import sellerIcon from "@/assets/icons/seller.svg";
import PixIcon from "@/assets/checkoutV2/paymentMethods/pix.svg";
import CreditCardIcon from "@/assets/checkoutV2/paymentMethods/creditCard.svg";
import BoletoIcon from "@/assets/checkoutV2/paymentMethods/boleto.svg";
// Utils
import { formatMoney } from "~~/utils/money";

export default {
  data() {
    const purchase = usePurchaseStore();
    const checkoutV2 = useCheckoutV2Store();
    const checkoutStore = useCheckoutStore();
    const product = useProductStore();
    const amountStore = useAmountStore();
    const personalStore = usePersonalStore();

    const map = new Map([
      ['PIX', 'Pix'],
      ['BOLETO', 'Boleto'],
      ['CREDIT_CARD', 'Cartão']
    ]);


    const mapIcons = new Map([
      ['PIX', PixIcon],
      ['BOLETO', BoletoIcon],
      ['CREDIT_CARD', CreditCardIcon]
    ]);

    const amountCredidCard = computed(() => purchase.first.amount);

    const methodv2 = computed(() => checkoutV2.method);

    const paymentMethod = computed(() => checkoutStore.method);


    const emailComputed = computed(() => {
      return product?.product?.seller?.company?.email || "";
    });

    const phoneComputed = computed(() => {
      return product?.product?.seller?.company?.support_telephone || "";
    });

    const isTextTooLong = computed(() => {
      return (emailComputed?.value?.length + phoneComputed?.value?.length) > 34;
    });

    const nameComputed = computed(() => {
      const company = product?.product?.seller?.company;
      return company?.fantasy_name || company?.name || product?.product?.seller?.name || "";
    });

    const currentDateFormatted = new Intl.DateTimeFormat('pt-BR', { 
      day: '2-digit', 
      month: 'long' 
    }).format(new Date());

    const route = useRoute();
    const queryKeys = Object.keys(route.query);
    const isEvent = queryKeys.some(x => x.includes('ticket_id'));

    const saleId = isEvent
        ? route.query.s_id ? route.query.s_id : route.query[queryKeys[0]].split("-s_id_")[1]
        : route.query.s_id;

    return {
      map,
      sellerIcon,
      PixIcon,
      CreditCardIcon,
      BoletoIcon,
      mapIcons,
      paymentMethod,
      product,
      amountStore,
      personalStore,
      isTextTooLong,
      currentDateFormatted,
      saleId,
      amountCredidCard,
      methodv2,
      phoneComputed,
      emailComputed,
      nameComputed
    };
  },
  methods: {
    formatDateToMonthYear(dateString: any) {
      const date = new Date(dateString);
        return new Intl.DateTimeFormat('pt-BR', { month: 'short', year: 'numeric' })
        .format(date)
        .replace('.', '')
        .replace(/\b(\w+)/, (match) => `${match}`);  
    },
    formatTranslation()  {
      const format = this.product?.product?.format;

      if (!format) {
        return "Sem tipo de produto";
      }

      const translations = {
        mentoring: "Mentoria",
        course: "Curso",
        event: "Evento",
        physical_product: "Produto Físico",
        others: "Outro",
        infoproduct: "Info Produto",
      } as const;

      const formatLower = format.toLowerCase() as keyof typeof translations;
      return translations[formatLower] || format;
    },
    formatPhoneNumber(phone: string){
      if (!phone) return "";

      const cleanedPhone = phone.replace(/^\+55/, "");

      const ddd = cleanedPhone.slice(0, 2);
      const number = cleanedPhone.slice(2);

      if (number.length === 8) {
        return `(${ddd}) ${number.slice(0, 4)}-${number.slice(4)}`;
      }
      if (number.length === 9) {
        return `(${ddd}) ${number.slice(0, 5)}-${number.slice(5)}`;
      }

      return "Número inválido";
    }
  },
};
</script>

<style scoped>
.title{
  color: var(--Old-800, #003B36);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 18px;
  font-style: normal;
  font-weight: 800;
  line-height: normal;
  margin-bottom: 16px;
}

.subtitle{
  color: var(--Gray-200, #999E9D);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: 150%; /* 21px */
  margin-bottom: 32px;
}

.title-card-item{
  color: var(--Old-800, #003B36);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  margin-bottom: 16px;
}

.content-item{
  display: flex;
  padding: 20px 24px;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  gap: 10px;
  align-self: stretch;
  margin-bottom: 32px;
  border-radius: 10px;
  border: 1px solid var(--Gray-50, #E5E7E7);
  background: var(--Gray-White, #FFF);
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.logo-conteiner{
  display: flex;
  justify-content: center;
  align-items: center;
}

.conteiner-item{
  display: flex;
  flex-direction: column;
}

.title-item{
  color: var(--Old-800, #003B36);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
  margin-bottom: 8px;
}

.subtitle-item{
  color: var(--Gray-200, #999E9D);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}

.subtitle-item-mini{
  color: var(--Gray-200, #999E9D);
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 13px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}

.img-product {
  width: 45px;
  height: 45px;
  border-radius: 45px;
}

.item-seller{
  flex-direction: column;
  align-items: flex-start;
}

.sub-item{
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  gap: 10px;
}

.separator {
  border: none;
  border-top: 1px solid #E5E7E7;
  margin: 10px 0;
  width: 100%;
}

.seller-info {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: #003B36;
  white-space: normal;
  word-break: break-word;
}

</style>
