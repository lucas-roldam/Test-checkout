<template>
  <div class="container-thanks">
    <div class="header">
      <p v-if="checkoutV2.method === 'credit_card'" class="text-header"> 
        Pago {{formatMoney(purchase.first.amount)}} via {{map.get(paymentMethod)}} Aproveite sua compra
      </p>
      <p v-else class="text-header">
        {{ sucessPayment ? 'Pago' : 'Pague' }} {{formatMoney(amountStore.getAmount)}} via {{map.get(paymentMethod)}} {{sucessPayment ? 'Aproveite sua compra' : 'e conclua sua compra' }}
      </p>
      <img class="img-product" :src="product.product.images[0]?.path"/>
    </div>
    <div class="content-card">
      <div
        class="badge-status"
        v-if="hasLeftPage || sucessPayment"
        :class="{ 'bg-success': sucessPayment }" 
      >
        <span class="text-badge-status" :class="{ 'text-success': sucessPayment }" >
          {{ !sucessPayment ? 'Pagamento pendente' : 'Pagamento aprovado!' }}
        </span> 
      </div>
      <CheckoutV2PixOrBoletoCode v-if="(paymentMethod === 'PIX' || paymentMethod === 'BOLETO') && !sucessPayment"></CheckoutV2PixOrBoletoCode>
      <CheckoutV2Success  v-if="paymentMethod === 'CREDIT_CARD' || sucessPayment"></CheckoutV2Success>
      <div class="logo-conteiner">
        <img :src="logo_gray"/>
      </div>
      <p class="text-footer">
        Você está efetuando o pagamento à Greenn Pagamentos e
        <br>
        Tecnologia LTDA
      </p>
    </div>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount } from 'vue';
// Stores
import { useAmountStore } from  "~~/store/modules/amount";
import { useCheckoutStore } from "~~/store/checkout";
import { useProductStore } from "~~/store/product";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
// Utils
import { formatMoney } from "~~/utils/money";
// Icons
import logo_gray from "@/assets/icons/logo_gray.svg";

const purchase = usePurchaseStore();
const checkoutV2 = useCheckoutV2Store();
const amountStore = useAmountStore();
const checkoutStore = useCheckoutStore();
const product = useProductStore();
const hasLeftPage = ref(false);

const handleVisibilityChange = () => {
  if (document.visibilityState === "hidden") {
     hasLeftPage.value = true;
  }
};

const map = new Map([
  ['PIX', 'Pix'],
  ['BOLETO', 'Boleto'],
  ['CREDIT_CARD', 'Cartão']
]);

onMounted(() => {
  document.addEventListener("visibilitychange", handleVisibilityChange);
});

onBeforeUnmount(() => {
  document.removeEventListener("visibilitychange", handleVisibilityChange);
});

const paymentMethod = computed(() => checkoutStore.method);

const sucessPayment = computed(() => {
  return paymentMethod.value === 'CREDIT_CARD' ? true : checkoutStore.sucessPayment;
});
</script>

<style scoped>
.container-thanks{
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #F0F2F5;
}

.header{
  display: flex;
  align-items: center;
  height: 100px;
  padding: 24px;
  gap: 50px;
  flex-shrink: 0;
  background-color: #F0F2F5;
}

.text-header{
  color: #003B36;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 18px;
  font-style: normal;
  font-weight: 600;
  line-height: 150%; /* 27px */
}

.content-card{
  background-color: #FFFFFF;
  flex: 1;
  padding: 24px;
}

.badge-status{
  display: flex;
  padding: 12px;
  justify-content: flex-start;
  align-items: center;
  border-radius: 8px;
  background: var(--Red-50, #FFF3ED);
  width: fit-content;
  margin-bottom: 16px;
}

.text-badge-status{
  color: var(--Red-500, #FF4820);
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
}

.bg-success{
  background: var(--Primary-50, #EBFEF6) !important;
}

.text-success{
  color: var(--Primary-600, #00B07F) !important;
}

.img-product {
  width: 45px;
  height: 45px;
  border-radius: 45px;
}

.logo-conteiner{
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 24px;
}

.text-footer{
  color: var(--Gray-200, #999E9D);
  text-align: center;
  font-feature-settings: 'liga' off, 'clig' off;
  font-family: "Plus Jakarta Sans";
  font-size: 10px;
  font-style: normal;
  font-weight: 400;
  line-height: 140%;
  margin-top: 24px;
}
</style>