<template>
  <section class="min-h-[60px] w-full px-6">
    <div class="discount-options">
      <p class="discount-options__title">
        Você desbloqueou descontos 🤑
      </p>
      <div class="discount-options__items">
        <div 
          v-for="(item, index) in bump_list" 
          :key="index"
          class="discount-options__item" 
          @click="setOrderBump(item)"
        >
          <div class="mb-[-45px]">
            <img class="discount_icon" :src="discount"/>
          </div>
          <div class="discount-options__bumps">
            <div class="discount-options__content">
              <div class="discount-options__details">
                <img :src="item.images[0].path" :alt="item.name" class="image" />
                <div class="discount-options__info">
                  <p class="discount-options__subtitle">{{ item.name }}</p>
                  <div class="discount-options__markdown">
                    <div :class="{'truncated': !expanded[index]}">
                      <MdPreview
                        :modelValue="item.description"
                        previewOnly
                      />
                    </div>
                    <span
                      v-if="item.description.length > 100"
                      @click.stop="toggleDescription(index)"
                      class="toggle-link"
                    >
                      {{ expanded[index] ? 'Ver menos' : 'Ver mais' }}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="discount-options__footer">
            <div class="discount-options__checkbox">
              <input
                type="checkbox"
                :id="`item-${index}`"
                v-model="item.selected"
                @click="setOrderBump(item)"
              />
              <label :for="`item-${index}`"></label>
              <span class="discount-options__status">
              {{ item.selected ? 'Produto adicionado!' : 'Incluir na compra!' }}
            </span>
            </div>
            <div class="discount-options__price-container">
              <span class="discount-options__current-price">{{ formatMoney(item.amount) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from 'vue';
import { MdPreview } from 'md-editor-v3';
import { formatMoney } from "~~/utils/money";
import { useCheckoutStore } from "@/store/checkout";
import { useCheckoutV2Store } from "~~/store/modules/checkoutV2";
import { useInstallmentsStore } from "~~/store/modules/installments";
import { useAmountStore } from "~~/store/modules/amount";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useProductStore } from "~~/store/product";
import discount from "@/assets/checkoutV2/orderBump/discount.svg";

const purchase = usePurchaseStore();
const installmentsStore = useInstallmentsStore();
const checkoutV2 = useCheckoutV2Store();
const checkout = useCheckoutStore();
const productStore = useProductStore();

const { getInstallments } = storeToRefs(installmentsStore);
const { bump_list } = storeToRefs(checkout);
const { contract_terms } = storeToRefs(productStore);

const expanded = ref([]);

const toggleDescription = (index) => {
  expanded.value[index] = !expanded.value[index];
};

function formatAmountText(installments = 1) {
  const { hasFees } = useProductStore();
  const { getInstallmentsTickets } = useInstallmentsStore();
  const { amount } = useAmountStore();

  const getAmount = !hasFees ? getInstallmentsTickets(amount, installments) : getInstallments.value(installments);
  return formatMoney(getAmount);
}

function setOrderBump(item) {
  item.selected = !item.selected;
  checkout.setProductList(item)

  const installment = checkoutV2.installment
  const installmentAmount = formatAmountText(Number(installment));
  checkoutV2.setPaymentData(Number(installment), installmentAmount);
  purchase.setCardsAmount();
}
</script>

<style lang="scss" scoped>
.discount-options {
  font-family: 'Plus Jakarta Sans', sans-serif;

  &__title {
    font-size: 14px;
    font-weight: 700;
    color: #003B36;
    margin-bottom: 16px;
  }

  &__items {
    display: flex;
    flex-direction: column;
    gap: 30px;
  }

  &__item {
    border: 1px dashed #5EA9FC;
    border-radius: 15px;
    padding: 24px ;
    background-color: #FFFFFF;
    cursor: pointer;
    margin-bottom: 16px;
  }

  &__bumps {
    display: flex;
    align-items: flex-start;
    gap: 12px;
  }

  .discount_icon {
    position: relative;
    top: -40px;
    left: 100%;
  }

  &__checkbox {
    display: flex;
    margin-left: 16px;
    align-items: center;

    input[type='checkbox'] {
      display: none;
    }

    label {
      display: inline-block;
      position: relative;
      border: 1px solid #2469EE;
      border-radius: 2px;
      width: 14px;
      height: 14px;
      cursor: pointer;

      &:after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 10px;
        height: 8px;
        background-image: url("@/assets/checkoutV2/orderBump/check.svg");
        background-size: contain;
        background-repeat: no-repeat;
        opacity: 0;
      }
    }

    input:checked + label {
      background-color: #2469EE;
      &:after {
        opacity: 1;
      }
    }
  }

  &__details {
    display: flex;
    gap: 12px;
  }

  &__info {
    display: flex;
    flex-direction: column;
  }

  &__subtitle {
    font-family: Plus Jakarta Sans;
    font-size: 14px;
    font-weight: 600;
    line-height: 17.64px;
    margin: 0;
    color: #003B36;
  }

  &__description-short {
    font-size: 12px;
    color: #666;
    margin: 0;
  }

  .image {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
  }

  &__footer {
    display: flex;
    margin-top: 16px;
    padding-top: 16px;
    padding-bottom: 16px;
    background-color: #EFF6FF;
    justify-content: space-between;
    align-items: center;
    border-radius: 10px;
  }

  &__price-container {
    display: flex;
    flex-direction: column;
  }

  &__current-price {
    font-family: Plus Jakarta Sans;
    font-size: 13px;
    font-weight: 600;
    line-height: 16.38px;
    color: #2469EE;
    margin-right: 16px;
  }

  &__status {
    font-family: Plus Jakarta Sans;
    font-size: 13px;
    font-weight: 500;
    line-height: 16.38px;
    color: #2469EE;
    margin-left: 16px;
  }

  &__toggle {
    margin-top: 8px;
    text-align: center;
  }

  &__markdown {
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 140%;
    text-align: left;
    margin-top: 12px;

    .truncated {
      max-height: 70px;
      overflow: hidden;
      display: -webkit-box;
      -webkit-box-orient: vertical;
    }
  }

  .toggle-link {
    font-family: Plus Jakarta Sans;
    font-size: 12px;
    font-weight: 400;
    line-height: 15.12px;
    color: #2469EE;
    cursor: pointer;
  }
}
</style>