<template>
  <footer class="checkout-footer fixed-footer px-6 py-4 bg-white shadow-lg">
    <div class="flex flex-col justify-content-center items-start w-full">
      <div v-if="product.allowedCoupon" class="flex w-full items-start gap-2 flex-wrap">
        <div v-if="!coupon.applied && !showCouponInput" class="coupon-insert w-full">
          <a @click="toggleCouponInput" class="coupon-button">
            Inserir cupom
          </a>
          <img :src="GreennGray" alt="Greenn logo" />
        </div>
        <div
          v-else-if="showCouponInput && !coupon.applied"
          class="relative flex items-center w-full"
        >
          <div class="relative w-full">
            <img :src="Coupon" alt="coupon" class="icon-coupon" />
            <input
              v-model="coupon.name"
              type="text"
              class="coupon-input pl-10 pr-16"
              placeholder="Insira o cupom"
            />
            <button
              @click="applyCoupon"
              class="coupon-button absolute right-2 top-1/2 -translate-y-1/2 text-[#3886F9] text-sm font-semibold cursor-pointer"
            >
              Aplicar
            </button>
          </div>
        </div>
        <div v-else class="flex items-center justify-between w-full">
          <p class="text-[#999E9D]">{{ couponNameComputed }}</p>
          <a @click="checkout.setCoupon(false, true)" class="coupon-button">
            Remover cupom
          </a>
        </div>
      </div>
      <div v-else class="without-coupon w-full">
        <img :src="GreennGray" alt="Greenn logo" />
      </div>

      <div class="footer-actions">
        <div class="payment-footer">
          <div
            v-if="methodComputed.method === 'credit_card' && checkoutV2.installment === 1"
            class="credit-payment-amount"
          >
            <p class="text-sm text-[#999E9D]">{{ checkoutV2.installment }}x de</p>
            <p class="text-lg font-bold text-[#003B36]">
              {{ formatMoney(totalAmountComputed) }}
            </p>
          </div>

          <div
            v-else-if="methodComputed.method === 'credit_card' && checkoutV2.installment !== 1"
            class="credit-payment-amount"
          >
            <p class="text-sm text-[#999E9D]">{{ checkoutV2.installment }}x de</p>
            <p class="text-lg font-bold text-[#003B36]">
              {{ amountByInstallmentComputed }}*
            </p>
          </div>

          <div v-else>
            <p class="text-lg font-bold text-[#003B36]">{{ formatMoney(totalAmountComputed) }}</p>
          </div>

          <div v-if="methodComputed.method === 'credit_card' && checkoutV2.installment !== 1">
            <p class="text-sm text-[#999E9D]">ou à vista {{ formatMoney(totalAmountComputed) }}</p>
          </div>
          <div v-else>
            <p class="text-sm text-[#999E9D]">Total a pagar</p>
          </div>
        </div>

        <button
          :disabled="paymentIsDisabledComputed"
          @click="callPayment()"
          :class="paymentIsDisabledComputed === true ? 'pay-button-disabled' : 'pay-button-enabled'"
        >
          Pagar com {{ methodComputed.methodButton }}
        </button>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { computed } from 'vue';
import * as Toast from "vue-toastification";
// Icons
import Greenn from "@/assets/checkoutV2/footer/greenn.svg";
import Coupon from "@/assets/checkoutV2/footer/coupon.svg";
import GreennGray from "@/assets/checkoutV2/footer/greenn-gray.svg";
// Utils
import { formatMoney } from "~~/utils/money";
//Stores
import { useAmountStore } from  "~~/store/modules/amount";
import { useCheckoutV2Store } from  "~~/store/modules/checkoutV2";
import { usePaymentStore } from "~~/store/modules/payment";
import { useCheckoutStore } from "~~/store/checkout";
import { useProductStore } from "@/store/product";
import { usePersonalStore } from "@/store/forms/personal";
import { useInstallmentsStore } from "~~/store/modules/installments";
import { usePurchaseStore } from "@/store/forms/purchase";

const { t, locale } = useI18n();
const payment = usePaymentStore();
const amount = useAmountStore();
const checkoutV2 = useCheckoutV2Store();
const checkout = useCheckoutStore();
const product = useProductStore();
const personalStore = usePersonalStore();
const installmentsStore = useInstallmentsStore();
const purchase = usePurchaseStore();

const { getInstallments } = storeToRefs(installmentsStore);
const { productName } = storeToRefs(product);
const { isPaymentFetching } = storeToRefs(payment);
const { coupon, captchaEnabled, getCouponName } = storeToRefs(checkout);

const methodComputed = computed(() => {
  return checkoutV2.getMethod;
});

const totalAmountComputed = computed(() => {
  return amount.getAmount;
});

const paymentIsDisabledComputed = computed(() => {
  checkoutV2.setPaymentIsDisabled();
  return checkoutV2.getPaymentIsDisabled;
});

const amountByInstallmentComputed = computed(() => {
  return checkoutV2.getAmountByInstallment;
});

const couponNameComputed = computed(() => {
  return getCouponName.value.toUpperCase();
});

const timeStemp = ref(null);

async function callPayment() {
  const newDateTimeStemp = new Date();

  if(timeStemp.value && (newDateTimeStemp.getTime() - timeStemp.value) < 1000) return

  timeStemp.value = newDateTimeStemp.getTime();

  if(!isPaymentFetching.value) {
    if (captchaEnabled.value) {
      //não colocar await pois nenhuma dessa funções retornam promises
      //https://developers.google.com/recaptcha/docs/display?hl=pt-br#js_api
      window.grecaptcha.reset();
      window.grecaptcha.execute();
    } else {
      await payment.payment(locale.value).finally(() => {
        payment.setPaymentLoading(false);
        payment.setPaymentFetching(false);
      })
    }
  }
}

const showCouponInput = ref(false);

function toggleCouponInput() {
  showCouponInput.value = true;
}

function formatAmountText(installments = 1) {
  const { hasFees } = useProductStore();
  const { getInstallmentsTickets } = useInstallmentsStore();
  const { amount } = useAmountStore();

  const getAmount = !hasFees ? getInstallmentsTickets(amount, installments) : getInstallments.value(installments);
  return formatMoney(getAmount);
}

watch(totalAmountComputed, (newAmount, oldAmount) => {
  if (newAmount !== oldAmount) {
    if (methodComputed.value.method === 'credit_card') {
      const installment = checkoutV2.installment
      const installmentAmount = formatAmountText(Number(installment));
      checkoutV2.setPaymentData(Number(installment), installmentAmount);
    }

    checkoutV2.setPaymentIsDisabled();
  }
});

function applyCoupon() {
  checkout.setCoupon()
    .then(() => {
      const toast = Toast.useToast();
      if (coupon.value.error || coupon.value.name === "") {
        toast.error('Cupom não aplicado, verfique e tente novamente');
        showCouponInput.value = false
        return
      }
      toast.info(
        `${t("checkout.cupom.header_aplicado")}${t(
          "checkout.cupom.no_produto"
        )}: ${productName.value.toUpperCase()}`
      );
      const installment = checkoutV2.installment
      const installmentAmount = formatAmountText(Number(installment));
      checkoutV2.setPaymentData(Number(installment), installmentAmount);
      purchase.setCardsAmount();
    })
}
</script>

<style scoped>
.pay-button-enabled {
  font-family: 'Plus Jakarta Sans', sans-serif;
  padding: 12px 24px;
  font-size: 14px;
  font-weight: 700;
  line-height: 20px;
  border-radius: 8px;
  background: #00B07F;
  color: #FFFFFF;
  height: 48px;
  border: none;
  cursor: pointer;
  white-space: nowrap;
  margin-left: auto;
}

.pay-button-disabled {
  font-family: 'Plus Jakarta Sans', sans-serif;
  padding: 12px 24px;
  font-size: 14px;
  font-weight: 700;
  line-height: 20px;
  border-radius: 8px;
  background: #00B07F;
  color: #FFFFFF;
  opacity: 0.4;
  height: 48px;
  border: none;
  cursor: pointer;
  white-space: nowrap;
  margin-left: auto;
}

.pay-button:hover {
  background-color: #027e5b;
}

.footer-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.payment-footer {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
}

.fixed-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 100;
}

.credit-payment-amount{
  display: flex;
  align-items: center;
  gap: 5px;
}

.checkout-footer {
  font-family: 'Plus Jakarta Sans', sans-serif;
  border-top: 1px solid #e5e7eb;
  display: flex;
  justify-content: space-between;
}

.checkout-footer a {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-weight: 500;
  cursor: pointer;
}

.checkout-footer p {
  font-family: 'Plus Jakarta Sans', sans-serif;
}

.checkout-footer button {
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.icon-coupon {
  font-size: 16px;
  color: #999e9d;
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}

.coupon-input {
  font-family: 'Plus Jakarta Sans', sans-serif;
  color: #003B36;
  width: 100%;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  font-size: 14px;
  height: 44px;
  box-sizing: border-box;
  max-width: none;
  text-transform: uppercase;
}

.coupon-input:focus {
  outline: none;
  border-color: #3886F9;
}

.coupon-button {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #3886F9;
  cursor: pointer;
}

.without-coupon {
  display: flex;
  flex-direction: row-reverse;
}

.coupon-button:hover {
  color: #3886F9;
}

.coupon-insert {
  font-family: 'Plus Jakarta Sans', sans-serif;
  color: #003B36;
  display: flex;
  justify-content: space-between;
}
</style>
