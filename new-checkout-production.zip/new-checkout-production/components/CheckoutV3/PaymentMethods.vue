<template>
  <section class="min-h-[60px] w-full px-6">
    <h2 class="title">Métodos de pagamento</h2>
    <div class="payment-methods-carousel">
      <div class="carousel-container" ref="carouselRef">
        <div 
          v-for="(method, index) in paymentMethods" 
          :key="method.id" 
          :class="[
            'payment-method', 
            { selected: selectedMethod === method.id }
          ]" 
          @click="selectMethod(method.id, method.button)"
        >
          <div class="recommended-badge" v-if="method.recommended">
            Recomendado
          </div>
          <div v-if="selectedMethod === method.id" class="method-icon">
            <img :src="method.iconSelected" :alt="method.title" />
          </div>
          <div v-else class="method-icon">
            <img :src="method.icon" :alt="method.title" />
          </div>
          <span class="method-button">{{ method.button }}</span>
        </div>
      </div>
    </div>

    <transition name="fade-slide">
      <div v-if="selectedMethod === 'credit_card'" class="payment-details">
        <div>
          <h3 class="method-title">Cartão de crédito</h3>
          <p class="method-description">Parcele em até 12x</p>
        </div>
        <CheckoutV2CreditCard />
      </div>
    </transition>

    <transition name="fade-slide">
      <div v-if="selectedMethod === 'boleto'" class="payment-details">
        <div>
          <h3 class="method-title">Boleto</h3>
          <p class="method-description">Vencimento em até 3 dias</p>
        </div>
        <CheckoutV2Document />
      </div>
    </transition>
  </section>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
// Icons
import PixIcon from "@/assets/checkoutV2/paymentMethods/pix.svg";
import CreditCardIcon from "@/assets/checkoutV2/paymentMethods/creditCard.svg";
import BoletoIcon from "@/assets/checkoutV2/paymentMethods/boleto.svg";
import PixIconSelected from "@/assets/checkoutV2/paymentMethods/pixSelected.svg";
import CreditCardIconSelected from "@/assets/checkoutV2/paymentMethods/creditCardSelected.svg";
import BoletoIconSelected from "@/assets/checkoutV2/paymentMethods/boletoSelected.svg";
// Stores
import { useCheckoutV2Store } from "~~/store/modules/checkoutV2";
import { useCheckoutStore } from "~~/store/checkout";

const checkoutV2Store = useCheckoutV2Store();
const checkoutStore = useCheckoutStore();
const carouselRef = ref(null);

const { allowed_methods } = storeToRefs(checkoutStore);

const paymentMethods = computed(() => {
  const validMethods = ["CREDIT_CARD", "BOLETO", "PIX"];
  const methods = allowed_methods.value
    .filter((item) => validMethods.includes(item))
    .map((item) => {
      switch (item) {
        case "CREDIT_CARD":
          return {
            id: "credit_card",
            title: "Cartão de crédito",
            button: "Cartão",
            description: "Parcele em até 12x",
            recommended: false,
            icon: CreditCardIcon,
            iconSelected: CreditCardIconSelected,
          };
        case "BOLETO":
          return {
            id: "boleto",
            title: "Boleto",
            button: "Boleto",
            description: "Vencimento em até 3 dias",
            recommended: false,
            icon: BoletoIcon,
            iconSelected: BoletoIconSelected,
          };
        case "PIX":
          return {
            id: "pix",
            title: "Pix",
            button: "Pix",
            description: "Aprovação imediata",
            recommended: false,
            icon: PixIcon,
            iconSelected: PixIconSelected,
          };
        default:
          return null;
      }
    });

  const priorities = { pix: 1, credit_card: 2, boleto: 3 };
  const sortedMethods = methods.sort((a, b) => priorities[a.id] - priorities[b.id]);

  if (sortedMethods.length > 0) {
    sortedMethods[0].recommended = true;
  }

  return sortedMethods;
});

const selectedMethod = ref(null);

const selectMethod = (id, button) => {
  selectedMethod.value = id;
  checkoutV2Store.setMethod(id, button);
  if (id !== "credit_card") {
    checkoutStore.setMethod(id.toUpperCase());
  }
  checkoutV2Store.setPaymentIsDisabled();
  
};

onMounted(() => {
  const firstMethod = paymentMethods.value[0];
  if (firstMethod) {
    selectedMethod.value = firstMethod.id;
    checkoutV2Store.setMethod(firstMethod.id, firstMethod.button);
    checkoutStore.setMethod(firstMethod.id.toUpperCase());
  }

  // Add horizontal scroll with mouse wheel
  if (carouselRef.value) {
    carouselRef.value.addEventListener('wheel', (e) => {
      e.preventDefault();
      carouselRef.value.scrollLeft += e.deltaY;
    });
  }
});
</script>

<style scoped>
.title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 700;
  line-height: 17.64px;
  color: #003B36;
}

.payment-methods-carousel {
  margin-bottom: 16px;
}

.carousel-container {
  display: flex;
  gap: 16px;
  overflow-x: auto;
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* IE and Edge */
  padding: 16px 0px 0px 0px;
}

.carousel-container::-webkit-scrollbar {
  display: none; /* Chrome, Safari, Opera */
}

.payment-method {
  padding: 16px 24px 16px 24px;
  gap: 10px;
  min-width: 93px;
  min-height: 103px;
  border: 2px solid #E5E7E7;
  border-radius: 8px;
  display: flex;
  cursor: pointer;
  position: relative;
  transition: all 0.2s ease;
  flex-direction: column;
}

.payment-method.selected {
  border-color: #00B07F;
  background: #FFFFFF;
}

.method-icon {
  width: 45px;
  height: 45px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.method-icon img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.method-button {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 12px;
  font-weight: 600;
  color: #003B36;
  text-align: center;
}

.recommended-badge {
  font-family: Plus Jakarta Sans;
  font-size: 10px;
  font-weight: 600;
  line-height: 12.6px;
  position: absolute;
  top: -13px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #EBFEF6;
  color: #00B07F;
  padding: 6px;
  border-radius: 50px;
  bottom: 87%;
}

.payment-details {
  margin-top: 20px;
  padding: 16px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
}

.method-title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
  margin-bottom: 16px;
}

.method-description {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #999E9D;
}

.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.5s ease;
}

.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.fade-slide-enter-to {
  opacity: 1;
  transform: translateY(0);
}

.fade-slide-leave-from {
  opacity: 1;
  transform: translateY(0);
}

.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(10px);
}
</style>