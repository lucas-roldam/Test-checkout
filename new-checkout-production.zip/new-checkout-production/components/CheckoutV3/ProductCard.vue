<template>
  <section class="min-h-[60px] w-full px-6">
    <h2 class="title">Produto</h2> 
    <div class="product-card">
      <div>
        <div class="product-info">
          <img :src="product.product.images[0]?.path" alt="product" class="image" />
          <div>
            <h3 class="product-title">{{ product.product.name }}</h3>
            <p class="product-description">{{ nameComputed }}</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
//Stores
import { useProductStore } from "~~/store/product";

const product = useProductStore();

const nameComputed = computed(() => {
  const company = product?.product?.seller?.company;
  return company?.fantasy_name || company?.name || product?.product?.seller?.name || "";
});
</script>

<style scoped>
.title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 700;
  line-height: 17.64px;
  margin-bottom: 16px;
  color: #003B36;
}

.product-card {
  font-family: 'Plus Jakarta Sans', sans-serif;
  display: flex;
  padding: 15px;
  margin-bottom: 16px;
  border: 1px solid #E5E7E7;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color 0.2s;
  background-color: #ffffff;
  width: 100%;
  box-shadow: 0px 10px 15px 0px rgba(0, 0, 0, 0.03);
}

.product-info {
  font-family: 'Plus Jakarta Sans', sans-serif;
  display: flex;
  align-items: center;
  gap: 10px;
}

.product-title {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 600;
  line-height: 17.64px;
  color: #003B36;
  margin-bottom: 16px;
}

.product-description {
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 17.64px;
  color: #999E9D;
}

.image {
  width: 45px;
  height: 45px;
  border-radius: 50%;
}
</style>
