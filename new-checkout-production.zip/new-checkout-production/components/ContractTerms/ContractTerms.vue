<script setup>
import { ref } from 'vue';
import ContractTermsModal from './ContractTermsModal.vue';
import { storeToRefs } from "pinia";
import { useProductStore } from "~~/store/product";
import ContractsIcon from "./ContractIcon.vue";

const productStore = useProductStore();
const { checkContractTerms } = storeToRefs(productStore);

const showModal = ref(false);

function openModal(openForlink = false) {
  setTimeout(() => {
    if (checkContractTerms.value || openForlink) {
      document.body.classList.add('no-scroll');
      showModal.value = true;
    }
  }, 500);
}

function closeModal() { 
    document.body.classList.remove('no-scroll');
    showModal.value = false; 
}
</script>

<template>
  <div class="container-terms">
    <div class="content-terms">
      <div>
        <BaseCheckbox
          :saveData="true"
          v-model:checked="checkContractTerms"
          :label="`Declaro que li e aceito os termos do contrato apresentado`"
          @update:checked="(checked) => { if (checked) openModal() }"
          :id="'checkContractTerms'"
        />
      </div>
      <div class="text-terms-conteiner"  @click="openModal">
        <ContractsIcon></ContractsIcon>
        <p class="text-terms">Termos e condições do contrato</p>
    </div>
  </div>
  <br>
  </div>

  <BaseModal :isContractTerm="true" :title="'Termos e Condições'" :is-open="showModal" @close="closeModal" :closeButton="true">
    <ContractTermsModal></ContractTermsModal>
  </BaseModal>
</template>

<style lang="scss" scoped>
.container-terms {
    display: flex;
    flex-direction: row;
    margin-top: 1.25rem;
    color: var(--txt-color);
    font-family: Montserrat;
    font-style: normal;
    gap: 0.5rem; 
}
.content-terms {
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 1.25rem; 
}
.text-terms {
    font-family: Montserrat;
    font-size: 14px;
    font-style: normal;
    font-weight: 600;
    line-height: 138.571%; /* 19.4px */
    text-decoration-line: underline;
    margin-left: 1.1rem;
}
.text-check {
    font-weight: 400;
    line-height: 1.2125rem; 
}
.text-terms-conteiner{
    display: flex;
    cursor: pointer;
}
</style>
