<!-- Modal.vue -->
<template>
  <div class="container-terms-modal text-terms-modal">
    <MdPreview
      :modelValue="formattedMarkdown"
      previewOnly
    />
  </div>
  <div class="footer-checkbox">
    <div>
      <BaseCheckbox
        :saveData="true"
        v-model:checked="checkContractTerms"
        :label="`Declaro que li e aceito os termos do contrato apresentado`"
        :id="'checkContractTermsModal'"
      />
    </div>
  </div>
</template>

<script setup>
import { defineEmits, defineProps } from 'vue';
import { MdPreview } from 'md-editor-v3';
import { storeToRefs } from "pinia";
import { useProductStore } from "~~/store/product";

const productStore = useProductStore();
const { checkContractTerms, contract_terms} = storeToRefs(productStore);

const props = defineProps({
  isVisible: Boolean
});

const formattedMarkdown = computed(() => {
  return contract_terms.value.body.replace(/\\/g, '\n')
});

const emit = defineEmits(['update:isVisible']);

</script>

<style scoped>
.container-terms-modal {
  padding: 1.25rem 2.375rem;
  align-items: center;
  border-radius: 0.625rem;
  background: rgba(247, 247, 247, 0.60);
  height: calc(100vh - 500px);
  overflow-y: scroll;
}

.container-terms-modal::-webkit-scrollbar {
  width: 0px;
  background: transparent;
}

.container-terms-modal {
  scrollbar-width: none;
}

.text-terms-modal{
  color: var(--txt-color);
  font-size: 13px;
  font-style: normal;
  font-weight: 400;
  line-height: 19.5px; 
}
.footer-checkbox{
  display: flex;
  padding: 1.25rem 2.375rem;
  gap: 20px;
}
.label-terms{
  color: #333;
  font-family: Montserrat;
  font-size: 0.875rem;
  font-style: normal;
  font-weight: 400;
  line-height: 138.571%; /* 1.2125rem */
}

</style>
