<script setup>
import safe_lock from "@/assets/footer/safe/safe_lock.svg";
import safe_product from "@/assets/footer/safe/safe_product.svg";
import safe_data from "@/assets/footer/safe/safe_data.svg";
const productStore = useProductStore();
const { t } = useI18n();
const { product } = storeToRefs(productStore);
const items = computed(() => {
  return [
    {
      image: safe_lock,
      label: t("components.footer.safe.first.label"),
      emphasis: t("components.footer.safe.first.emphasis"),
    },
    {
      image: safe_product,
      label: t("components.footer.safe.second.label"),
      emphasis: t("components.footer.safe.second.emphasis"),
    },
    {
      image: safe_data,
      label: t("components.footer.safe.third.label"),
      emphasis: t("components.footer.safe.third.emphasis"),
    },
  ];
});
</script>

<template>
    <div class="text-disclaimer-size text-gray-400 px-4">
    <p>
      {{t("disclaimer.ao_concluir")}}
      <a
        href="https://greenn.com.br/termos-de-uso-greenn/"
        target="_blank"
        rel="noopener noreferrer"
        class="text-green-600 underline hover:text-green-800"
      >
      {{t("disclaimer.termos_de_uso")}}
      </a>
      {{t("disclaimer.e")}}
      <a
        href="https://greenn.com.br/politicas-e-termos-greenn"
        target="_blank"
        rel="noopener noreferrer"
        class="text-green-600 underline hover:text-green-800"
      >
      {{t("disclaimer.demais_politicas")}}
      </a>
      {{t("disclaimer.plataforma_dados")}}
    </p>
    <p class="mt-2">
      {{t("disclaimer.responsabilidade_da_oferta")}}
      <strong class="font-medium">{{
            product.seller.company
              ? product.seller.company.fantasy_name || product.seller.company.name
              : product.seller.name
          }}</strong>{{t("disclaimer.realiza_venda_plataforma")}}
    </p>
  </div>
  <section class="flex w-full justify-around">
      <span
        class="flex flex-col items-center"
        v-for="(item, index) in items"
        :key="index"
        :class="`item-${index + 1}`"
      >
        <img
          :src="item.image"
          :alt="`icon safe ${index + 1}`"
          width="25"
          height="34"
          class="mb-2 h-[34px] w-[25px]"
        />
        <p class="text-[11px] text-txt-color">{{ item.label }}</p>
        <p class="emphasis text-[13px] font-semibold">{{ item.emphasis }}</p>
      </span>
  </section>
</template>

<style lang="scss" scoped>
.item-1 {
  .emphasis {
    color: #00e4a0;
  }
}
.item-2 {
  .emphasis {
    color: #3483fa;
  }
}
.item-3 {
  img {
    filter: invert(1);
  }
  .emphasis {
    color: #81858e;
  }
}

[data-theme="light"] {
  .item-3 {
    img {
      filter: none;
      opacity: 1;
    }
  }
}

.text-disclaimer-size {
  font-size: 10px;
}
</style>
