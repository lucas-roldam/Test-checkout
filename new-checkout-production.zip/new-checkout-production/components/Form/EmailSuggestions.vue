<template>
  <div class="position-relative w-full col-span-12">
    <BaseInput 
      type="email" 
      class="col-span-12 foc" 
      @change="emit(`changeValue`)"
      @blur="blurValidation()" 
      @focus="validateShow()"
      :label="label"
      :placeholder="placeholder" 
      input-name="email-field" 
      input-id="email-field"
      v-model="emailModel"
      v-if="!visible"
      :disabled="disabled" 
      rules="email"
      ref="child"
      @downKey="increaseEmailIndex()"
      @upKey="decreaseEmailIndex()"
      @enterKey="selectEmailIndex()"
    >
      <template #error>
        {{ templateError }}
      </template>
    </BaseInput>
    <div v-if="showSuggestions" class="email-suggestions">
      <div 
        v-for="(domain, index) in filteredEmail" 
        @mousedown="addEmail(domain)" 
        :class="selectedEmailIndex == index &&  !isMobile ? 'selected-email' : ''"
      >
        {{ (emailModel.split('@')[0]) + '@' + domain}}
      </div>
    </div>
  </div>
</template>

<script setup>
  import { ref, watch, defineProps, defineModel} from 'vue';

  const props = defineProps({
    label: String,
    placeholder: String,
    errorValue: Boolean,
    disabled: Boolean,
    templateError: String,
    visible: Boolean
  });

  const emailModel = defineModel();
  const after = ref('');
  const showSuggestions = ref(false);
  const selectedEmailIndex = ref(0);

  const domainsEmails = [
    'gmail.com',
    'outlook.com',
    'hotmail.com',
    'icloud.com',
    'yahoo.com',
  ];

  watch(emailModel, (newValue) => {
    const regex = /^[^@]*@$/
    if (regex.test(newValue)) {
      showSuggestions.value = true;
      filterEmail();
    } else {
      showSuggestions.value = false;
    }
    if (newValue && newValue.includes('@')) {
      showSuggestions.value = true;
      if (!newValue.includes('@') || newValue.endsWith('.com') || newValue.endsWith('.br')) {
        showSuggestions.value = false;
      }
      after.value = newValue.split('@')[1];
      filterEmail();
    }
  });
  function validateShow(){
    const regex = /^[^@]*@$/
    if (regex.test(emailModel.value)) {
      showSuggestions.value = true;
      filterEmail();
    }
  }
  const filteredEmail = ref([]);
  function filterEmail(){
    if (after.value) {      
      filteredEmail.value = domainsEmails.filter((domain) => domain.startsWith(after.value));
      return filteredEmail;
    }
    filteredEmail.value = domainsEmails;
    return filteredEmail;
  }
  function decreaseEmailIndex(){
    if (selectedEmailIndex.value > 0) { 
      --selectedEmailIndex.value;
    }
  }
  function increaseEmailIndex(){
    if (filteredEmail.value.length > selectedEmailIndex.value + 1) {
      ++selectedEmailIndex.value;
    }
  }

  const emit = defineEmits(['changeValue', 'blurValue'])
  const child = ref(null);
  function selectEmailIndex(){
    if( !after.value.endsWith('.com') && !after.value.endsWith('.br') && filteredEmail.value[selectedEmailIndex.value] !== undefined){
      let newEmail = filteredEmail.value[selectedEmailIndex.value];
      emailModel.value = (emailModel.value.split('@')[0] + '@' + newEmail);
    }
    if (child.value) {
      child.value.emitInputEvent();
    }
    emit(`changeValue`);
    emit('blurValue');
  }
  function addEmail(domain){
    emailModel.value = emailModel.value.split('@')[0] +'@'+  domain;
    showSuggestions.value = false;
    if (child.value) {
      child.value.emitInputEvent();
    }
    emit(`changeValue`);
    emit('blurValue');
  }
  const isMobile = computed( () => {
    return window.screen.width <= 768;
  })

  function blurValidation() {
      showSuggestions.value = false
      emit('blurValue');
  }
</script>

<style scoped lang="scss">
.position-relative{
  position: relative;
}
[data-theme="dark"] .email-suggestions {
  &:not(:hover) > .selected-email{
    background-color: var(--background);
  }
  > div {
    &:hover {
      background-color: var(--background);
    }
  }
}
.email-suggestions {
  position:absolute;
  top: calc(100% - 25px);
  z-index: 45;
  background-color: var(--checkout);
  width: 100%;
  border: 1px solid var(--border-color);
  border-radius: 0 0 10px 10px;
  color: var(--txt-color);
  &:not(:hover) > .selected-email{
    background-color: var(--white-medium);
  }
  > div {
    padding: 10px;
    border-bottom: 1px solid var(--border-color);
    transition: .3s;
    cursor: pointer;
    &:hover {
      background-color: var(--white-medium);
    }
    &:last-child {
      border-bottom: none;
    }
  }
}
</style>