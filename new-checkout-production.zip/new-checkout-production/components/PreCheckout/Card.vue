<template>
  <section
    class="card flex h-auto w-full max-w-[771.66px] flex-col gap-4 rounded-lg bg-checkout"
  >
    <slot />
  </section>
</template>

<style lang="scss" scoped>
.card {
  border: solid 1px #E5E5E5;
}
</style>
