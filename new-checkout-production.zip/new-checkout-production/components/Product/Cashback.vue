<script setup>
import { formatMoney } from "~~/utils/money";
import { storeToRefs } from "pinia";
import { useProductStore } from "@/store/product";
import money_cashback from "@/assets/icons/money_cashback.svg";
import target_cashback from "@/assets/icons/target_cashback.svg";
import { checkout } from "~/rules/form-validations";
import { useAmountStore } from "~~/store/modules/amount";

const product = useProductStore();
const { cashback } = storeToRefs(product);
const hasCashback = cashback.value.meta && cashback.value.months;
const { maximunCashbackAmount } = useCheckoutStore();
const amountStore = useAmountStore();

const isLimitedCashback = computed(() => {
  return amountStore.getAmount > maximunCashbackAmount;
});


const { t } = useI18n();

</script>

<template>
  <section v-if="hasCashback" class="mt-2">
    <section
      class="cashback-item flex w-full flex-col items-center gap-5 rounded border border-bd-color p-5 mb-3"
    > 
      <span class="badge-cashback">✅ {{ $t("checkout.guarantee_of_success") }}</span>
      <span
        class="pl-1 flex w-full flex-nowrap items-center justify-start gap-2"
      >
        <img
          :src="money_cashback"
          alt="icon money cashback"
          class="mr-[20px]"
        />
        <div class="w-full flex-col">
          <p v-if="!isLimitedCashback" class="w-full text-[14px] font-bold text-[#009488]">
            {{ $t("checkout.with_cashback") }}
          </p>
          <p v-else class="w-full text-[14px] font-bold text-[#009488]">
            {{ $t("checkout.with_limited_cashback") + formatMoney(maximunCashbackAmount)}} 
          </p>
          <p class="w-full text-[11px] text-[#009488]">
            {{ $t("checkout.sponsored_by_greenn") }}
          </p>
        </div>
      </span>
    </section>

    <section
      class="cashback-target flex w-full flex-col items-center gap-5 rounded border border-bd-color p-5"
    >
      <span
        class="flex w-full flex-nowrap items-center justify-start gap-2"
      >
        <img
          :src="target_cashback"
          alt="icon money cashback target"
          class="mr-[20px]"
        />
        <p class="w-full text-[14px] text-[#000]">
          {{ $t("checkout.sell") }} 
          {{ formatMoney(cashback.meta) }} 
          {{ $t("checkout.in") }} 
          {{ cashback.months }} 
          {{ cashback.months === 1 ? $t("checkout.month") : $t("checkout.months") }} 
          {{ $t("checkout.to_get_cashbash") }} 
        </p>
      </span>
    </section>

  </section>
</template>

<style lang="scss" scoped>
.cashback-item {
  background-color: rgba(0, 148, 136, 0.1);
  color: #009488;
  position: relative;
}
.badge-cashback {
  position: absolute;
  background: #006B63;
  border-radius: 5px;
  color: #fff;
  padding: 11px;
  padding-top: 6px;
  padding-bottom: 5px;
  font-size: 12px;
  font-weight: 600;
  line-height: 15px;
  letter-spacing: 0em;
  text-align: left;
  top: -15px;
  right: -10px;
}
.cashback-target {
  background-color: #F7F7F7;
;
}
</style>
