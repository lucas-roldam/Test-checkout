<script setup>
import * as Toast from "vue-toastification";
import { storeToRefs } from "pinia";
import { useCheckoutStore } from "@/store/checkout";
import { useProductStore } from "@/store/product";
import { usePaymentStore } from "~~/store/modules/payment";

const payment = usePaymentStore();
const checkout = useCheckoutStore();
const product = useProductStore();
const preCheckout = usePreCheckoutStore();
const { sellerHasFeatureTickets } = storeToRefs(preCheckout);
const { coupon, hasCoupon, history_subscription } = storeToRefs(checkout);
const { productName } = storeToRefs(product);

const { t } = useI18n();
const isOpen = ref(!!coupon?.value?.name);

function apply() {
  payment.setPaymentLoading(true);

  checkout.setCoupon().then(() => {
    if (coupon.value.applied) {
      const toast = Toast.useToast();
      toast.info(
        `${t("checkout.cupom.header_aplicado")}${t(
          "checkout.cupom.no_produto"
        )}: ${productName.value.toUpperCase()}`
      );
    }
  }).finally(() => {
    payment.setPaymentLoading(false);
  });
}

const hasSubscriptionCoupon = computed(() => {
  if (history_subscription.value === null || history_subscription.value.coupon === null) {
    return false;
  }
  return true;
});

function getInstallmentDate(installmentNumber) {
  const today = new Date();
  const dueDate = new Date(today.setMonth(today.getMonth() + installmentNumber - 1)); // Incrementa meses com base no número da parcela
  return dueDate.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
}

</script>

<template>
  <section
    class="item-collapse flex w-full flex-col items-center gap-5 rounded border border-bd-color"
    :class="[!isOpen ? 'pb-4' : 'pb-0']"
    :opened="isOpen"
  >
    <span
      class="flex w-full flex-nowrap items-center justify-start gap-2 p-4 -mb-5"
      @click="isOpen = !isOpen"
    >
      <Icon name="carbon:calendar" size="28" class="text-blue-600" />
      <p class="w-full text-[15px] font-semibold text-txt-color">
        <!-- pegar quantidade de parcelas e seus valores -->
        {{ product.product.offer_charges }}x de {{ formatMoney(product.amount) }}
      </p>
      <Icon
        name="ic:arrow-drop-down"
        size="22"
        class="text-gray-400 duration-500"
        :class="{ 'rotate-180': isOpen }"
      />
    </span>
    <!-- Abre e nao tem cupom aplicado -->
    <section
      v-if="isOpen"
      class="flex w-full flex-col gap-5 px-2 py-3"
    >
      <table class="w-full text-sm font-semibold text-left -mt-4">
        <thead>
          <th class="p-3">Parcela</th>
          <th class="p-3">Cobrança</th>
          <th class="p-3">Valor</th>
        </thead>
        <tbody>
          <tr class="font-normal" v-for="index in product.product.offer_charges" :key="index" :class="index % 2 === 0 ? 'bg-[#fbfcfc]' : 'bg-white'">
            <td class="p-3">
              {{ index }}º parcela
            </td>
            <td class="p-3">
              {{ getInstallmentDate(index + 1) }}
            </td>
            <td class="p-3">
              {{ formatMoney(product.amount) }}
            </td>
          </tr>
        </tbody>
      </table>
    </section>
  </section>
</template>
