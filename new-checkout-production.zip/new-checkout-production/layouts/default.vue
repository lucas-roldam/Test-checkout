<script setup>
import { useRequestURL, useRuntimeConfig } from '#app'
// Stores
import { useCustomCheckoutStore } from "~~/store/customCheckout";
import { useProductStore } from "~~/store/product";
import { useCheckoutStore } from "~~/store/checkout";
import { usePersonalStore } from "~~/store/forms/personal";
import { useStepStore } from "~~/store/modules/steps";
// Logos
import logo_gray from "@/assets/icons/logo_gray.svg";
import logoHeaven from "@/assets/heaven/logo.svg";
import logoGreenn from "@/assets/logos/logo.png";

// Variables
const custom_checkout = useCustomCheckoutStore();
const product = useProductStore();
const checkout = useCheckoutStore();
const greennWrapper = ref(null);
const requestURL = useRequestURL();
const runtimeConfig = useRuntimeConfig();
const stepStore = useStepStore();
const route = useRoute();
const { isMobileResponsive } = storeToRefs(stepStore);
// Computed properties
const logo = computed(() => (checkout.isHeaven ? "Heaven" : "Greenn"));

const logoSrc = computed(() => {
  if (showAlternativeLoading) return alternativeLogo;
  if (logo.value === "Heaven") return logoHeaven;
  return logoGreenn;
});

const apiUrls = "http://localhost:3000,https://cadernointeligentecheckout.com.br,https://checkoutstg.cadernointeligentecheckout.com.br,https://neymarjrcadernodigital.com.br";

const urlOrigin = requestURL.origin;
const showAlternativeLoading = apiUrls.includes(urlOrigin);
const isLogoValidated = ref(false);
const isRendered = ref(false);

const alternativeLogo = runtimeConfig.public.ALTERNATIVE_LOGO;

onMounted(() => {
  onClientRender();
  custom_checkout.greennWrapper = greennWrapper;
  if (process.client) {
    isLogoValidated.value = true;
  }
});

function onClientRender() {
  isRendered.value = true;
}
</script>

<template>
  <main
    v-if="!isRendered"
    class="flex h-screen w-screen flex-col items-center justify-center gap-8 bg-background"
  >
    <CheckoutV2PreLoading/>
  </main>

  <main
    v-else-if="isRendered && checkout.isLoading && isMobileResponsive"
    class="flex h-screen w-screen flex-col items-center justify-center gap-8 bg-white"
  >
    <CheckoutV2LoadingPurchasing />
  </main>

  <main
    v-else-if="isRendered && !checkout.isLoading && isMobileResponsive"
    ref="greennWrapper" 
    class="flex min-h-screen w-full flex-col items-center bg-white"
    :data-theme="product.isValid() ? custom_checkout.theme : 'light'"
    :data-theme_color="
      product.isValid() ? custom_checkout.themeColor : '#00E4A0'
    "
  >
    <CheckoutV3Header v-if="route.query.version === 'v3'"/>
    <CheckoutV2Header v-else/>

    <section class="flex w-full max-w-[1240px] justify-center overflow-x-hidden">
      <section v-if="route.query.version === 'v3'" class="flex w-full flex-col-reverse gap-2 mb-[24px] md:items-start md:overflow-x-auto lg:flex-row">
        <slot />
      </section>
      <section v-else class="flex w-full ml-[24px] mr-6 flex-col-reverse gap-8 md:items-start md:overflow-x-auto lg:flex-row">
        <slot />
      </section>
    </section>

    <CheckoutV2Footer v-if="product.isValid()" />
    <CheckoutV2PaymentButton v-if="product.isValid()" />
  </main>

  <main
    v-else-if="checkout.isLoading"
    class="flex h-screen w-screen flex-col items-center justify-center gap-8 bg-background"
  >
    <img
      v-if="isLogoValidated"
      :src="logoSrc"
      :alt="logo === 'Heaven' ? 'logo do Heaven' : 'logo do Greenn'"
      width="250"
      class="animate-bounce"
    />
  </main>
  
  <main
    v-else
    ref="greennWrapper" 
    class="flex min-h-screen w-full flex-col items-center gap-10 bg-background"
    :data-theme="product.isValid() ? custom_checkout.theme : 'light'"
    :data-theme_color="
      product.isValid() ? custom_checkout.themeColor : '#00E4A0'
    "
  >
    <BaseHeader />
    <section class="flex w-full max-w-[1240px] justify-center">
      <BaseCard
        class="mt-10 flex max-w-[800px] flex-col items-center gap-6 border border-b-4 border-gray-200 border-b-error px-5 py-10 md:px-20"
        v-if="!product.isValid() || (product.product.method == 'FREE' && (checkout.allow_free_offers == null || checkout.allow_free_offers === 'DISABLED'))"
      >
        <Icon name="mdi:close-circle" size="120" class="text-error" />
        <h1 class="text-center text-2xl">{{ $t("general.error_message") }}</h1>
      </BaseCard>
      <section
        v-else
        class="flex flex-col-reverse gap-10 overflow-x-hidden px-3 md:items-start md:overflow-x-auto lg:flex-row"
      >
        <slot />
      </section>
    </section>
    <BaseFooter v-if="product.isValid()" />
    <ButtonWhatsapp v-if="product.isValid()" />
  </main>
</template>

<style scoped>
   .purchase-processing {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: 'Arial', sans-serif;
    text-align: center;
    background-color: #ffffff;
    color: #333;
  }

  .loader-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .circular-loader {
    position: relative;
    width: 15rem; /* Tamanho maior */
    height: 15rem; /* Tamanho maior */
    border:  .5rem solid #f0f0f0;
    border-top: .5rem solid #38b58f;
    border-radius: 50%;
    animation: spin 2s linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }

  .purchase-info {
    position: relative;
    top: -10rem;
  }

  .title {
    color: #999E9D;
    text-align: center;
    font-feature-settings: 'liga' off, 'clig' off;
    font-family: "Plus Jakarta Sans";
    font-size: 16px;
    font-style: normal;
    line-height: normal;
  }

  .value {
    color: #003B36;
    text-align: center;
    font-feature-settings: 'liga' off, 'clig' off;
    font-family: "Plus Jakarta Sans";
    font-size: 32px;
    font-style: normal;
    font-weight: 800;
    line-height: normal;
  }

  .security {
    margin-top: 32px;
    display: flex;
    align-items: center;
  }

  .security-icon {
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #38b58f;
  }

  .security-icon img {
    width: 20px;
    height: 20px;
    margin-right: 8px;
  }

  .logo {
    position: absolute;
    bottom: 24px;
  }

  .logo img {
    width: 100px;
    height: auto;
  }
  .text-icon{
    margin-left: 1rem;
    color: #999E9D;
    font-family: "Plus Jakarta Sans";
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
  }
  .text-subtitle-1{
      color: #003B36;
      text-align: center;
      font-feature-settings: 'liga' off, 'clig' off;
      font-family: "Plus Jakarta Sans";
      font-size: 18px;
      font-style: normal;
      font-weight: 700;
      line-height: normal;
  }
  .text-subtitle-2{
    color: #999E9D;
    text-align: center;
    font-feature-settings: 'liga' off, 'clig' off;
    font-family: "Plus Jakarta Sans";
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 150%;
  }
</style>
