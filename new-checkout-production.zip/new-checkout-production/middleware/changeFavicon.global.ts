import { useRequestURL } from '#app';

export default defineNuxtRouteMiddleware(() => {
  const requestURL = useRequestURL();
  const apiUrls = "http://localhost:3000,https://cadernointeligentecheckout.com.br,https://checkoutstg.cadernointeligentecheckout.com.br,https://neymarjrcadernodigital.com.br";
  const envFavicon = "https://greenn-production-public.s3.us-east-1.amazonaws.com/edutech/Fav.webp";

  let newFavicon = apiUrls.includes(requestURL.origin) ? envFavicon : '/faviconGreenn.ico';

  if (process.client) {
    const favicon = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
    if (favicon) {
      favicon.remove();
    }

    const newLink = document.createElement('link');
    newLink.rel = 'icon';
    newLink.href = newFavicon;
    document.head.appendChild(newLink);
  }
});