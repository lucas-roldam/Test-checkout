<script setup>
import { onMounted } from 'vue';

onMounted(() => {
  setTimeout(() => {
    window.location.href = "https://greenn.com.br/";
  }, 2000);
});
</script>

<template>
  <main class="flex h-screen w-screen justify-center">
    <h1 class="mt-[20vh] text-6xl font-semibold text-gray-400">
      Esta página não foi encontrada...
    </h1>
  </main>
</template>
