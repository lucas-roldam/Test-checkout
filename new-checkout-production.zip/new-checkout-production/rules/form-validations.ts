import * as yup from "yup";
import * as Toast from "vue-toastification";

// Stores
import { useStepStore } from "@/store/modules/steps";
import { usePhoneValidation } from "@/store/modules/phoneInput";
import { usePersonalStore } from "@/store/forms/personal";
import { useAddressStore } from "@/store/forms/address";
import { usePurchaseStore } from "@/store/forms/purchase";
import { useCheckoutStore } from "@/store/checkout";
import { useProductStore } from "~~/store/product";

export function checkout() {
  const store = useCheckoutStore();
  return storeToRefs(store);
}

export const validateRequired = yup.string().required();
export const validateName = yup.string().min(4).matches(/[A-Za-z]/, 'O nome deve conter pelo menos uma letra').required();
export const validateEmail = yup.string().email().required();
export const validateDocument = yup
  .string()
  .test("cpfCnpj", "", (value) => validateCpfCnpj(value))
  .required();

export const validateZip = computed(() => {
  const store = useCheckoutStore();
  const { global_settings } = storeToRefs(store);

  return global_settings.value.country === 'BR' ? yup.string().min(9).required() : yup.string().min(5).required();
});
export const validateStreet = yup.string().min(4).required();
export const validateNumber = yup.string().required();
export const validateCity = yup.string().min(3).required();
export const validateNeighborhood = yup.string().min(3).required();
export const validateState = yup.string().min(2).required();

export const validateCardNumber = yup.string().max(16).required();
export const validateCvc = yup.string().min(3).max(4).required();
export const validateNameOnCard = yup.string().min(4).matches(/[A-Za-z]/, 'O nome deve conter pelo menos uma letra').required();
export const validateExpiryMonth = yup.string().min(2).max(2).required();
export const validateExpiryYear = yup.string().min(4).max(4).required();
export const validateCardAmount = yup.number().positive().min(1).required();

export const validateFirstStepWithoutDocument = async (returnThree?: boolean): Promise<boolean> => {
  const personalStore = usePersonalStore();
  const phoneStore = usePhoneValidation();
  const { name, cellphone, email } = storeToRefs(personalStore)
  const { isValid } = storeToRefs(phoneStore)

  const validName = await validateName.isValid(name.value);
  const validEmail = await validateEmail.isValid(email.value);
  const validPhone = isValid.value;

  const stepStore = useStepStore();
  const { isEmailValid } = storeToRefs(stepStore);
  if (returnThree) {
    personalStore.setIsFormValidWithoutDocument(validName && validEmail && validPhone);
    return validName && validEmail && validPhone;
  }

  personalStore.setIsFormValidWithoutDocument(validName && validEmail && isEmailValid.value && validPhone);

  return validName && validEmail && isEmailValid.value && validPhone;
};

export const validateFirstStep = async (returnThree?: boolean): Promise<boolean> => {
  const personalStore = usePersonalStore();
  const phoneStore = usePhoneValidation();
  const { name, document, cellphone, email } = storeToRefs(personalStore)
  const { isValid } = storeToRefs(phoneStore)

  const validName = await validateName.isValid(name.value);
  const validEmail = await validateEmail.isValid(email.value);
  const validPhone = isValid.value;
  const currentCountry: any = useState("currentCountry");
  const showDocumentInput = ["BR", "MX", "UY", "AR", "CL"].includes(
    currentCountry.value
  );
  const stepStore = useStepStore();
  const { isEmailValid, isMobileResponsive } = storeToRefs(stepStore);
  
  if(isMobileResponsive.value){
    personalStore.setIsFormValid(validName && validEmail);
    return validName && validEmail;
  }

  if (returnThree) {
    personalStore.setIsFormValid(validName && validEmail && validPhone);
    return validName && validEmail && validPhone;
  }
  if (showDocumentInput) {
    const store = useCheckoutStore();
    const { hasPhone } = storeToRefs(store);
    const validDocument = await validateDocument.isValid(document.value);
    if (hasPhone?.value?.length >= 13) {
      personalStore.setIsFormValid(validName && validEmail && validDocument);
      return validName && validEmail && validDocument;
    }

    const result = (
      validName &&
      validEmail &&
      isEmailValid.value &&
      validPhone &&
      validDocument
    );

    personalStore.setIsFormValid(result);

    return result;
  }

  personalStore.setIsFormValid(validName && validEmail && isEmailValid.value && validPhone);

  return validName && validEmail && isEmailValid.value && validPhone;
};

export const validateSecondStep = async (): Promise<boolean> => {
  const productStore = useProductStore();
  const checkout = useCheckoutStore();

  const { hasIntegrationWithGreennEnvios, bump_list } = storeToRefs(checkout);
  // Inicializa a variável de integração de envio como falsa
  let validShippingIntegration = false;

  // Calcula se algum bump tem integração com envios
  const hasIntegrationBump = computed(() => {
    return bump_list.value.some(
      (item) => item.hasIntegrationWithGreennEnvios === true
    );
  });

  // Verifica se é necessário aplicar taxas de envio dinâmicas ou se existem bumps com taxas de envio
  if (
    (productStore.hasShippingFee && productStore.isDynamicShipping) ||
    !!checkout.getBumpsWithShippingFee.length
  ) {
    // Verifica se não existe integração com envios ou se nenhum bump tem integração e ajusta a validação
    if (
      (!hasIntegrationWithGreennEnvios.value &&
        hasIntegrationBump.value == false) ||
      (!!checkout.getBumpsWithShippingFee.length &&
        checkout.getBumpsWithShippingFee.some(
          (bump) => !bump.hasIntegrationWithGreennEnvios
        ))
    ) {
      validShippingIntegration = false;
    } else {
      // Se as condições acima não forem verdadeiras, assume que a integração é válida
      validShippingIntegration = true;
    }
  } else {
    // Se não há necessidade de taxa de envio dinâmica nem bumps com taxas, assume como válida a integração
    validShippingIntegration = true;
  }

  const addressStore = useAddressStore();
  const { charge, shipping, sameAddress } = storeToRefs(addressStore);

  const validZip = await validateZip.value.isValid(charge.value.zipcode);
  const validStreet = await validateStreet.isValid(charge.value.street);
  const validNumber = await validateNumber.isValid(charge.value.number);
  const validCity = await validateCity.isValid(charge.value.city);
  const validNeighborhood = await validateNeighborhood.isValid(charge.value.neighborhood);
  const validState = await validateState.isValid(charge.value.state);

  if (!sameAddress.value) {
    const validChargeZip = await validateZip.value.isValid(shipping.value.zipcode);
    const validChargeStreet = await validateStreet.isValid(shipping.value.street);
    const validChargeNumber = await validateNumber.isValid(shipping.value.number);
    const validChargeCity = await validateCity.isValid(shipping.value.city);
    const validChargeNeighborhood = await validateNeighborhood.isValid(shipping.value.neighborhood);
    const validChargeState = await validateState.isValid(shipping.value.state);

    return (
      validZip &&
      validStreet &&
      validNumber &&
      validCity &&
      validNeighborhood &&
      validState &&
      validChargeZip &&
      validChargeStreet &&
      validChargeNumber &&
      validChargeCity &&
      validChargeNeighborhood &&
      validChargeState &&
      validShippingIntegration
    );
  }

  return (
    validZip &&
    validStreet &&
    validNumber &&
    validCity &&
    validNeighborhood &&
    validState &&
    validShippingIntegration
  );
};

export const validateThristStep = async (): Promise<boolean> => {
  const purchaseStore = usePurchaseStore();
  const checkout = useCheckoutStore();
  const { first, second } = storeToRefs(purchaseStore);

  if (["PIX", "BOLETO"].includes(checkout.method)) {
    purchaseStore.setIsFormValid(true)
    return true;
  }

  const validNameOnCard = await validateNameOnCard.isValid(
    first.value.holder_name
  );
  const validCardNumber = await validateCardNumber.isValid(
    first.value.number.replace(/\s/g, "")
  );
  const validExpiryMonth = await validateExpiryMonth.isValid(first.value.month);
  const validExpiryYear = await validateExpiryYear.isValid(first.value.year);
  const validCvc = await validateCvc.isValid(first.value.cvv);

  if (checkout.method === "TWO_CREDIT_CARDS") {
    const validNameOnCardSecond = await validateNameOnCard.isValid(
      second.value.holder_name
    );
    const validCardNumberSecond = await validateCardNumber.isValid(
      second.value.number.replace(/\s/g, "")
    );
    const validExpiryMonthSecond = await validateExpiryMonth.isValid(
      second.value.month
    );
    const validExpiryYearSecond = await validateExpiryYear.isValid(
      second.value.year
    );
    const validCvcSecond = await validateCvc.isValid(second.value.cvv);

    const result = (
      validNameOnCard &&
      validCardNumber &&
      validExpiryMonth &&
      validExpiryYear &&
      validExpiryMonthSecond &&
      validExpiryYearSecond &&
      validCvcSecond &&
      validCvc &&
      validNameOnCardSecond &&
      validCardNumberSecond
    )

    purchaseStore.setIsFormValid(result)

    return result;
  }

  const stepStore = useStepStore();
  const { isMobile, isMobileResponsive } = storeToRefs(stepStore);
  const currentCountry: any = useState("currentCountry");
  const showDocumentInput = ["BR", "MX", "UY", "AR", "CL"].includes(
    currentCountry.value
  );
  const personalStore = usePersonalStore();
  const { document } = storeToRefs(personalStore);

  if (isMobile.value && showDocumentInput) {
    const validDocument = isMobileResponsive ? true : validateDocument.isValidSync(document.value);

    if (["PIX", "BOLETO", "FREE"].includes(checkout.method)) {
      purchaseStore.setIsFormValid(validDocument)
      return validDocument;
    }

    const result = (
      validNameOnCard &&
      validCardNumber &&
      validExpiryMonth &&
      validExpiryYear &&
      validCvc &&
      validDocument
    );

    purchaseStore.setIsFormValid(result)

    return result;
  }

  const result = (
    validNameOnCard &&
    validCardNumber &&
    validExpiryMonth &&
    validExpiryYear &&
    validCvc
  );

  purchaseStore.setIsFormValid(result)

  return result;
};

export const validateAll = async (isUpdateSubscription: boolean): Promise<boolean> => {
  const checkout = useCheckoutStore();
  const stepStore = useStepStore();
  const { isMobile, isMobileResponsive } = storeToRefs(stepStore);
  const validStepOne = isMobileResponsive ? true : await validateFirstStep();

  let validStepTwo = true;
  if (!isUpdateSubscription && !isMobileResponsive) {
    validStepTwo = await validateSecondStep();
  }
  const validStepThree = await validateThristStep();

  if (checkout.showAddressStep) {
    const productStore = useProductStore();
    const { hasIntegrationWithGreennEnvios, bump_list } = storeToRefs(checkout);

    const hasIntegrationBump = computed(() => {
      return bump_list.value.some(item => item.hasIntegrationWithGreennEnvios === true);
    });

    if (!validStepTwo) {
      // verifica se é necessário integração com envio, baseado nas condições de produto e bumps
      const needsShippingIntegration = (productStore.hasShippingFee && productStore.isDynamicShipping) ||
        !!checkout.getBumpsWithShippingFee.length;

      if (needsShippingIntegration) {
        // verifica se existe a integração necessária com envios ou se todos os bumps têm integração
        const hasRequiredIntegration = hasIntegrationWithGreennEnvios.value &&
          (!checkout.getBumpsWithShippingFee.length ||
            checkout.getBumpsWithShippingFee.every(bump => bump.hasIntegrationWithGreennEnvios));

        if (!hasRequiredIntegration) {
          // se houver integração configurada nos bumps, retorna verdadeiro
          if (hasIntegrationBump.value) {
            return true;
          }

          // exibe um erro via toast se não houver integração de envio e retorna falso
          const toast = Toast.useToast();
          toast.error("Esse produto não possui integração para envio");
          return false;
        }
      }
    }


    if (
      checkout.method === "CREDIT_CARD" ||
      checkout.method === "TWO_CREDIT_CARDS" ||
      isMobile.value
    ) {
      return validStepOne && validStepTwo && validStepThree;
    }
    return validStepOne && validStepTwo;
  }

  if (
    checkout.method === "CREDIT_CARD" ||
    checkout.method === "TWO_CREDIT_CARDS"
  ) {
    return validStepOne && validStepThree;
  }
  if (checkout.method === "BOLETO" || checkout.method === "PIX") {
    const personalStore = usePersonalStore();

    const { document } = storeToRefs(personalStore);
    const validDocument =  isMobileResponsive ? true : await validateDocument.isValid(document.value);
    return validStepOne && validDocument;
  }
  return validStepOne;
};

const validateCpfCnpj = (value: any) => {
  //Quando é um um documento de outro pais desabilita a validação de CPF
  const currentCountry: any = useState("currentCountry");
  if (currentCountry.value != 'BR') return true;

  if (!value) return false;

  const cleanValue = value.replace(/[^\d]/g, "");
  if (!cleanValue) return false;

  if (cleanValue.length === 11) {
    let sum = 0;
    let remainder;

    if (cleanValue === "00000000000") return false;

    for (let i = 1; i <= 9; i++) {
      sum += Number(cleanValue.charAt(i - 1)) * (11 - i);
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== Number(cleanValue.charAt(9))) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) {
      sum += Number(cleanValue.charAt(i - 1)) * (12 - i);
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== Number(cleanValue.charAt(10))) return false;
  } else if (cleanValue.length === 14) {
    let sum = 0;
    let position = 5;
    let remainder;

    if (cleanValue === "00000000000000") return false;

    for (let i = 0; i < 12; i++) {
      sum += Number(cleanValue.charAt(i)) * position;
      position = position === 2 ? 9 : position - 1;
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== Number(cleanValue.charAt(12))) return false;

    sum = 0;
    position = 6;
    for (let i = 0; i < 13; i++) {
      sum += Number(cleanValue.charAt(i)) * position;
      position = position === 2 ? 9 : position - 1;
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== Number(cleanValue.charAt(13))) return false;
  } else {
    return false;
  }

  return true;
};

export const phoneValidation = () => {
  const personalStore = usePersonalStore();
  const { validPhone } = storeToRefs(personalStore);
  return validPhone.value;
};
