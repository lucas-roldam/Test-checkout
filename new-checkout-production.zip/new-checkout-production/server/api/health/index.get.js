export default defineEventHandler((event) => {
  return 'Ok'
});
