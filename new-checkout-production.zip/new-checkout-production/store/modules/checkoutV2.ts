import { defineStore } from "pinia";
import { type CheckoutV2State } from "~~/types";

export const useCheckoutV2Store = defineStore("CheckoutV2", {
  state: (): CheckoutV2State => ({
    method: 'pix',
    methodButton: 'Pix',
    installment: '',
    amountByInstallment: '',
    paymentIsDisabled: false,
    hasError: true
  }),
  getters: {
    getMethod(state) {
      const data = { 
        method: state.method,
        methodButton: state.methodButton
      }
      return data;
    },
    getPaymentIsDisabled(state) {
      return state.paymentIsDisabled;
    },
    getAmountByInstallment(state) {
      return state.amountByInstallment;
    }
  },
  actions: {
    setPaymentData(installment: string, amountByInstallment: string) {
      this.installment = installment;
      this.amountByInstallment = amountByInstallment;
    },
    setMethod(method: string, methodButton: string) {
      this.method = method;
      this.methodButton = methodButton;
    },
    setHasError(hasError: boolean) {
      this.hasError = hasError;
    },
    setPaymentIsDisabled() {
      if (this.method === 'boleto' && this.hasError) {
        return this.paymentIsDisabled = true;
      }
      return this.paymentIsDisabled = false;
    },
  },
});
