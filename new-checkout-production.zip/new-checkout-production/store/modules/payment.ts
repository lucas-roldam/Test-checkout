// Utils
import { GreennLogs } from "@/utils/greenn-logs";

// Types
import {
  Payment,
  Product,
  PaymentError,
  SaleElement,
  CurrencyData,
  PurcharseCard,
  GlobalSettingsCard,
  IAddress
} from "~~/types";

// Rules
import { validateAll } from "@/rules/form-validations";

//Notifications
import * as Toast from "vue-toastification";

// Stores
import { usePersonalStore } from "../forms/personal";
import { useAddressStore } from "../forms/address";
import { usePurchaseStore } from "../forms/purchase";
import { useLeadsStore } from "./leads";
import { useCheckoutStore } from "../checkout";
import { usePreCheckoutStore } from "../preCheckout";
import { useInstallmentsStore } from "./installments";
import { useAmountStore } from "./amount";
import { useCustomCheckoutStore } from "~~/store/customCheckout";
import { useHeadersStore } from "../headers";
import { validateCardBrand } from "~/utils/validateCardBrand";
import { useStepStore } from "~~/store/modules/steps";

// External SDK

export function leadsStore() {
  const store = useLeadsStore();
  return store;
}

export function checkoutStore() {
  const store = useCheckoutStore();
  return store;
}

export function productStore() {
  const store = useProductStore();
  return store;
}

export function personalStore() {
  const store = usePersonalStore();
  return store;
}

export function installmentsStore() {
  const store = useInstallmentsStore();
  return store;
}

export function addressStore() {
  const store = useAddressStore();
  return store;
}

export function purchaseStore() {
  const store = usePurchaseStore();
  return store;
}

export function preCheckout() {
  const store = usePreCheckoutStore();
  return store;
}

export function headerStore() {
  const store = useHeadersStore();
  return store;
}

export function amountStore() {
  const store = useAmountStore();
  return store;
}

export const usePaymentStore = defineStore("Payment", {
  state: () => ({
    error: false,
    error_message: "",
    hasSent: false,
    // Payment button loading
    loading: false,
    fetching:false,
    attempts: []
  }),
  getters: {
    isPaymentLoading: (state) => state.loading,
    isPaymentFetching: (state) => state.fetching,
    getAttempts: (state) => state.attempts,
  },
  actions: {
    addAttempts(newAttempts: any[] = []) {
      this.attempts.push(...newAttempts)
    },
    setPaymentLoading(value = false) {
      this.loading = value;
    },
    setPaymentFetching(value = false) {
      this.fetching = value;
    },
    setCardDigitsIfNull(value, card = {}) {
      if (card.first_digits == null || card.last_digits == null) {
        const first = value.replace(/\s+/g, '').substring(0, 6);
        const last = value.replace(/\s+/g, '').slice(-4);

        return { first, last };
      }

      return { first: card.first_digits, last: card.last_digits };
    },
    async payment(language: string, isUpdateSubscription = false) {
      const checkoutStore = useCheckoutStore();
      const productStore = useProductStore();
      const personalStore = usePersonalStore();
      const addressStore = useAddressStore();
      const purchaseStore = usePurchaseStore();
      const installmentsStore = useInstallmentsStore();
      const amountStore = useAmountStore();
      const preCheckout = usePreCheckoutStore();
      const stepStore = useStepStore();

      const {
        method,
        product_id,
        product_offer,
        uuid,
        captchaEnabled,
        captcha_code,
        selectedCountry,
        hasPhysicalProduct,
        product_list,
        hasAffiliateId,
        installments,
        coupon,
        hasUpsell,
        ticket_installments,
        url,
        paypal_details,
        shipping_selected,
        products_client_statistics,
        history_subscription,
        urlClientId,
        urlClientDocument,
        reuseCreditCard,
        whatsappSaleId,
        getIsWorldpay,
        getIsPagarmeV5,
        assoc_ticket,
        getWorldpayCards
      } = checkoutStore;

      const {
        productName,
        is_gift,
        gift_message,
        isDynamicShipping,
        hasTicketInstallments,
        hasAffiliationLead,
        product,
        product_global_settings,
        recipientIsActivated,
        baas_activited,
        checkContractTerms,
        specific_gateway,
      } = productStore;

      const { name, email, document, cellphone } = personalStore;
      const { charge, shipping, sameAddress } = addressStore;
      const { first, second } = purchaseStore;
      const { getInstallments, getTotal, getTotalTickets } = installmentsStore;
      const { getOriginalAmount, getAmount } = amountStore;
      const { sellerHasFeatureTickets, getBatches } = preCheckout;

      if (!this.fetching) {
        this.setPaymentLoading(true);
        this.setPaymentFetching(true);
        const allValid = await validateAll(isUpdateSubscription);
        if (!allValid) {
          this.hasSent = true;
          this.setPaymentLoading(false);
          this.setPaymentFetching(false);
          return;
        }

        const leadsStore = useLeadsStore();
        leadsStore.changeStep(3);
        const total = computed(() => {
          if (method === "BOLETO" && hasTicketInstallments > 1) {
            return getTotal(ticket_installments);
          }
          if (["CREDIT_CARD", "TWO_CREDIT_CARDS"].includes(method)) {
            if (sellerHasFeatureTickets) {
              return getTotalTickets();
            }
            return getTotal();
          }
          return getInstallments(1);
        });

        let data: Payment = {
          // Purchase infos
          method: getOriginalAmount === 0 ? "FREE" : method,
          amount: getOriginalAmount,
          total: total.value,
          installments:
            method === "BOLETO" ? ticket_installments : installments,
          // product infos
          product_id: product_id.value,
          products: product_list.map((item: Product) => ({
            product_id:
              product.product_type_id == 3 && sellerHasFeatureTickets
                ? item.product_id
                : item.id,
            product_offer: item.hash,
            user_identification: item.user_identification,
          })),
          // proposal_id: proposal_id,
          // User details
          name: name,
          email: email.trim(),
          cellphone: cellphone.replace(/[^\d+]/g, ""),
          document: document,
          uuid: uuid,
          country_code: selectedCountry,
          // client_statistic: products_client_statistics.value,
          // Address
          zipcode: charge.zipcode ? charge.zipcode.replace(/[-]/g, "") : null,
          street: charge.street ?? "",
          number: charge.number ?? "",
          complement: charge.complement ?? "",
          neighborhood: charge.neighborhood ?? "",
          city: charge.city ?? "",
          state: charge.state ?? "",
          // Others
          language,
          metas: url.query,
          upsell_id: hasUpsell ? hasUpsell.value : null,          
          wpp_id: whatsappSaleId,
          reuse_credit_card: reuseCreditCard,
          assoc_ticket: assoc_ticket
        };
        
        if (sellerHasFeatureTickets) {
          data.batches = getBatches
            .map((item: any) => ({
              batch_id: item.id,
              selected_tickets: item.selected_batch_tickets,
            }))
            .filter((batche) => batche.selected_tickets !== 0);
        }

        if (captchaEnabled) {
          data.captcha = captcha_code;
        }
        if (method === "PAYPAL") {
          data.paypal = paypal_details;
        }
        // Gift
        if (is_gift) {
          data.is_gift = is_gift;
          data.gift_message = gift_message;
        }
        // Physical product
        if (hasPhysicalProduct && !isUpdateSubscription) {
          const address: any = sameAddress ? charge : shipping;

          data = {
            ...data,
            shipping_address_zip_code: address?.zipcode?.replace(/[-]/g, ""),
            shipping_address_street: address.street,
            shipping_address_number: address.number,
            shipping_address_complement: address.complement,
            shipping_address_neighborhood: address.neighborhood,
            shipping_address_city: address.city,
            shipping_address_state: address.state,
            shipping_selected: JSON.stringify({
              address,
              ...shipping_selected,
            }),
          };

          if (isDynamicShipping && !isUpdateSubscription) {
            data.shipping_selected = JSON.stringify({
              address,
              ...shipping_selected,
            });
          }

          if(!isUpdateSubscription){
            product_list.forEach((item: any) => {
              if (item?.shipping) {
                const index = data.products
                  .map((prod) => prod.product_id)
                  .indexOf(item.id);
                const shippingSelected: any = shipping_selected;
  
                data.products[index].shipping_amount = item.shipping.amount;
                data.products[index].shipping_service_id = item.shipping.id;
                data.products[index].shipping_service_name = item.shipping.name;
                data.products[index].shipping_selected = JSON.stringify({
                  address,
                  ...shipping_selected,
                });
              }
            });
          }
        }

        // Address validation for all products
        if (checkoutStore.showAddressStep && !isUpdateSubscription) {
        const address: IAddress = sameAddress ? charge : shipping;
        
        const isAddressIncomplete = !address.zipcode ||
         !address.street ||
         !address.number || 
         !address.city || 
         !address.state ||
         !address.neighborhood;

          if (isAddressIncomplete) {
            this.validateError({ 
              code: "INCOMPLETE_ADDRESS",
              status: "error", 
              sales: [] 
            });
            
            this.setPaymentLoading(false);
            this.setPaymentFetching(false);
            return;
          }
        }
          
        // Affiliate id
        const affiliate_id = useCookie(`affiliate_${product_id}`);
        const affiliate = useCookie("affiliate");
        if (hasAffiliateId) {
          data.affiliate_id = Number(hasAffiliateId);
        } else if (!hasAffiliationLead && affiliate_id.value) {
          data.affiliate_id = affiliate_id.value;
        } else if (hasAffiliationLead && affiliate.value) {
          data.affiliate_id = affiliate.value;
        }
        // Coupon
        if (coupon.applied && !!coupon.name) {
          data.products[0].coupon = coupon.name.toUpperCase();
        }
        /* When method is Credit card */
        if (
          ["CREDIT_CARD", "DEBIT_CARD", "TWO_CREDIT_CARDS"].includes(method)
        ) {
          // const config = useRuntimeConfig();
          // await this.setVisitorIdOnHeader()

          let parsedFirstAmount = Number(
            first.amount
              .toString()
              .replace("R$", "")
              .replace(".", "")
              .replace(",", ".")
          );
          let firstCardAmountWithoutInterest = parsedFirstAmount;
          if (method === "TWO_CREDIT_CARDS") {
            let percentageFirstCard = parsedFirstAmount / total.value;
            firstCardAmountWithoutInterest = getAmount * percentageFirstCard;
          }
          let cards: any = [];

          let card = {
            total: Number(parsedFirstAmount).toFixed(2),
            amount: Number(firstCardAmountWithoutInterest).toFixed(2),
            card_cvv: first.cvv,
            card_expiration_date: `${first.month}${first.year}`,
            card_holder_name: first.holder_name,
            card_number: first.number,
          };

          if (history_subscription?.contract_amount) {
            card.total = Number(history_subscription?.contract_amount).toFixed(2);
            card.amount = Number(history_subscription?.contract_amount).toFixed(2);
          }

          cards.push(card);

          if (method === "TWO_CREDIT_CARDS") {
            let parsedSecondAmount = Number(
              second.amount
                .toString()
                .replace("R$", "")
                .replace(".", "")
                .replace(",", ".")
            );
            cards.push({
              total: Number(parsedSecondAmount).toFixed(2),
              amount: Number(
                getAmount - firstCardAmountWithoutInterest
              ).toFixed(2),
              card_cvv: second.cvv,
              card_expiration_date: `${second.month}${second.year}`,
              card_holder_name: second.holder_name,
              card_number: second.number,
            });
          }
          data.cards = cards;
          
        }
        const allowed_installments = [
          "CREDIT_CARD",
          "TWO_CREDIT_CARDS",
          "DEBIT_CARD",
          "BOLETO",
        ];
        if (!allowed_installments.includes(method)) {
          delete data.installments;
        }
        const currency_data: CurrencyData = {
          local_currency: "BRL",
          base_currency: "BRL",
        };
        data.currency_data = currency_data;
        // Registrando log boleto
        let dataLog = Object.assign({}, data);
        GreennLogs.logger.info("🟡 Dados da Compra", {
          name: `Enviando objeto da compra [${method}]`,
          objetoCompra: JSON.stringify(dataLog),
        });
        checkoutStore.setLoading(true);

        try {
          let promises = [];

          let errorRequestPriority = false;

          let cardsPriority = [];
          let isCard = ["CREDIT_CARD", "DEBIT_CARD", "TWO_CREDIT_CARDS"].includes(method);

          if (data.cards) {

            for (let i = 0; i < data.cards.length; i++) {
              const card = data.cards[i];
              if (
                "card_holder_name" in card &&
                "card_number" in card &&
                "card_expiration_date" in card
              ) {

                let card_number = card.card_number.replace(/\s/g, "");

                cardsPriority.push({
                  holder_name: card.card_holder_name,
                  number: card_number,
                  exp_month: card.card_expiration_date
                    ? card.card_expiration_date.substring(0, 2)
                    : null,
                  exp_year: card.card_expiration_date
                    ? card.card_expiration_date.substring(4)
                    : null,
                  cvv: card.card_cvv,
                  costumer: this.customerData(data)
                });
              }
            }  
          }

          let attemps =  [...this.getAttempts];
           //Payload da Request que verifrica a Prioridade de Gateway
           let dataGateway = {
              system: "CHECKOUT",
              payment_method: method,
              action: isCard ? "CARD" : null,
              attempts: attemps,
              installments: data.installments ?? 1,
              cards: cardsPriority,
              seller_id: product.seller.id
            };


            //Sucesso Priority
            const handleResponsePriority = (responseGateway: any) => {
              //Atualiza o Gateway vindo da Rota priorityGateway
              let gateway = responseGateway.gateway;
              
              if (gateway) {
                data.gateway = gateway;
              }
              // Atualizar o objeto data.cards[i] mantendo os campos amount e total
              if (data.cards && isCard) {
                
               let attempts = responseGateway.attempts;
               if(attempts){
                this.addAttempts(attempts);
               }

               for (let i = 0; i < responseGateway.cards.length; i++) {
                  let amount = data.cards[i].amount; // Armazenar o valor do campo amount
                  let total = data.cards[i].total; // Armazenar o valor do campo total
                  
                  
  
                  let cardRespose = responseGateway.cards[i];

                  const expirationMonth = cardRespose.data?.month?.toString().padStart(2, '0');
                  const expirationYear = cardRespose.data?.year?.toString();
                  
                  const expiration_date = expirationMonth && expirationYear
                  ? `${expirationMonth}/${expirationYear}`
                  : undefined;

                  const card_digits = this.setCardDigitsIfNull(first.number, cardRespose.data);
                  

                  data.cards[i] = {
                    id: cardRespose.id,
                    last_digits: card_digits.last,
                    first_digits: card_digits.first,
                    customer: cardRespose.customer || null,
                    amount,
                    total,
                    brand: cardRespose.data?.brand || null,
                    is_v5: getIsPagarmeV5,
                    expiration_date
                  };
                }
              }
            };
  
            //Erro Priority
            const errorResponse = (error: any) =>{
              // Tratar erros
              errorRequestPriority = true;
              let dataError = Object.assign(
                {},
                error?.value?.response?._data
              );
              dataError.code = dataError.object;
  
              if (dataError && !dataError.code) {
                dataError.code = error?.type;
              }
              
              this.validateError(dataError);
            }

            //Request Priority
            let promise = await this.priorityGateway(dataGateway)
            .then((responseGateway) => {
              //Se der 200 Retorna o resultado
              if(responseGateway){
                handleResponsePriority(responseGateway) 
              }
              else{
                errorResponse(responseGateway);    
                errorRequestPriority = true;
              }
              
            })
            .catch((err) => {
              errorResponse(err);    
              errorRequestPriority = true;
            });
            promises.push(promise);

            

          data.check_contract_terms = checkContractTerms;

          // Aguardar a resolução de todas as promessas usando Promise.all()
          await Promise.all(promises);
          if(!isUpdateSubscription && !errorRequestPriority) {
            // Payment request

            const { product_global_settings } = useProductStore()

            const setting = product_global_settings.find(store => store.key === 'FINGERPRINT_SETTINGS')            
            const fingerSetting = setting.value === "ENABLED"
      
            await useApi()
              .create("/payment", data, {}, false, false, true , fingerSetting)
              .then(async(res) => {
                if (
                  res.sales !== undefined &&
                  Array.isArray(res.sales) &&
                  res.sales.every((item: SaleElement) => item.success)
                ) {
                  GreennLogs.logger.info("🟢 Success Compra", {
                    name: "Compra concluída com sucesso",
                    product_id: product_id,
                  });
                  let query: any = {};
                  const principal_product = res.sales
                    .filter(
                      (item: SaleElement) => item.product.name === productName
                    )
                    .pop();
                  // Set principal product query
                  if (principal_product?.chc || res?.sales[0]?.chc)
                    query.chc = principal_product?.chc || res?.sales[0]?.chc;
                  if (principal_product?.token || res?.sales[0]?.token)
                    query.token =
                      principal_product?.token || res?.sales[0]?.token;
                  if (principal_product?.sale_id || res?.sales[0]?.sale_id) {
                    delete query.chc;
                    query.s_id = res.sales[0].sale_id;
                  }
                  if (!!product_offer) query.offer = product_offer;

                  // Set query bumps
                  const route = useRoute();

                  // Se o produto for do tipo evento
                  if (
                    product?.product_type_id == 3 &&
                    sellerHasFeatureTickets
                  ) {
                    product_list.forEach(
                      (
                        ticket: { id: number; name: string; hash: string },
                        i
                      ) => {
                        const sale = res.sales.find(
                          (item: any) => item.product.offer_hash === ticket.hash
                        );
                        if (sale)
                          query["ticket_id_" + i] =
                            ticket.id + "-s_id_" + sale.sale_id;
                      }
                    );
                  } else {
                    const keys = Object.keys(route.query);
                    const bumps = product_list.filter(
                      (item: Product) => item.id !== parseInt(product_id)
                    );

                    bumps.forEach((bump: Product) => {
                      const index = keys
                        .filter(
                          (key) => route.query[key] == bump.id.toString()
                        )
                        .pop();
                      const sale = res.sales
                        .filter((item: any) => item.product.name === bump.name)
                        .pop();
                      if (!!sale && !!index) {
                        if (bump.type === "SUBSCRIPTION") {
                          if (sale.sale_id) {
                            query[index] =
                              route.query[index] +
                              "-chc_" +
                              sale.chc +
                              "-s_id_" +
                              sale.sale_id;
                          } else {
                            query[index] =
                              route.query[index] + "-chc_" + sale.chc;
                          }
                        } else {
                          query[index] =
                            route.query[index] + "-s_id_" + sale.sale_id;
                        }
                      }
                    });
                  }

                  const router = useRouter();
                  router.push({
                    path: `/${product_id}/obrigado`,
                    query,
                  });

                  return;
                }
                if (
                  Array.isArray(res?.sales) &&
                  res.sales.some((item: SaleElement) => !item.success)
                ) {
                  this.validateError(res?.sales[0]);
                  return;
                }
                if(
                  res?.code !== 200 && res?.attempts !== undefined) {

                  let attempts = [...res?.attempts];
                  this.addAttempts(attempts); 
                  
                  const noRetryPayment = [
                    'ORDER_BUMP_ERROR',
                    'INVALID_CVV',
                    'INSUFFICIENT_FUNDS',
                    'INVALID_PAYMENT_TYPE',
                    'INVALID_INSTALLMENTS',
                    'SUSPECTED_FRAUD',
                    'INVALID_CREDIT_CARD'
                  ];

                  if(!noRetryPayment.includes(res?.type) && !noRetryPayment.includes(res?.object)) {
                    await this.retryPayment(language,isUpdateSubscription);
                    return;
                  }
                }
                if ((res.status === "error" && !res.sales?.success) ||  res?.code !== 200 ) {
                  this.validateError(res);
                  return;
                }
                
              })
              .catch((err) => {
                console.error(err);                
                checkoutStore.setLoading(false);                              
                this.validateError(err.value?.data);               
                this.setPaymentLoading(false);
              })
              .finally(() => {
                this.setPaymentFetching(false);
                this.setPaymentLoading(false);
              });

          } else if(!errorRequestPriority) {
            // Payment request
            const body = {
              client_id: urlClientId,
              product_type: "COMMON",
              amount: data.amount,
              cpf_cnpj: urlClientDocument,
              cards: data.cards,
              id: product_id,
              gateway: data.gateway
            }

            await useApi()
              .update(`/payment/${product_id}`, body, {}, false, false, true)
              .then((res) => {
                if (
                  res.sales !== undefined &&
                  Array.isArray(res.sales) &&
                  res.sales.every((item: SaleElement) => item.success)
                ) {
                  GreennLogs.logger.info("🟢 Success Compra", {
                    name: "Compra concluída com sucesso",
                    product_id: product_id,
                  });
                  let query: any = {};
                  const principal_product = res.sales
                    .filter(
                      (item: SaleElement) => item.product.name === productName
                    )
                    .pop();
                  // Set principal product query
                  if (principal_product?.chc || res?.sales[0]?.chc)
                    query.chc = principal_product?.chc || res?.sales[0]?.chc;
                  if (principal_product?.token || res?.sales[0]?.token)
                    query.token =
                      principal_product?.token || res?.sales[0]?.token;
                  if (principal_product?.sale_id || res?.sales[0]?.sale_id) {
                    delete query.chc;
                    query.s_id = res.sales[0].sale_id;
                  }
                  if (!!product_offer) query.offer = product_offer;

                  // Set query bumps
                  const route = useRoute();

                  // Se o produto for do tipo evento
                  if (
                    product?.product_type_id == 3 &&
                    sellerHasFeatureTickets
                  ) {
                    product_list.forEach(
                      (
                        ticket: { id: number; name: string; hash: string },
                        i
                      ) => {
                        const sale = res.sales.find(
                          (item: any) => item.product.offer_hash === ticket.hash
                        );
                        if (sale)
                          query["ticket_id_" + i] =
                            ticket.id + "-s_id_" + sale.sale_id;
                      }
                    );
                  } else {
                    const keys = Object.keys(route.query);
                    const bumps = product_list.filter(
                      (item: Product) => item.id !== parseInt(product_id)
                    );

                    bumps.forEach((bump: Product) => {
                      const index = keys
                        .filter(
                          (key) => route.query[key] == bump.id.toString()
                        )
                        .pop();
                      const sale = res.sales
                        .filter((item: any) => item.product.name === bump.name)
                        .pop();
                      if (!!sale && !!index) {
                        if (bump.type === "SUBSCRIPTION") {
                          if (sale.sale_id) {
                            query[index] =
                              route.query[index] +
                              "-chc_" +
                              sale.chc +
                              "-s_id_" +
                              sale.sale_id;
                          } else {
                            query[index] =
                              route.query[index] + "-chc_" + sale.chc;
                          }
                        } else {
                          query[index] =
                            route.query[index] + "-s_id_" + sale.sale_id;
                        }
                      }
                    });
                  }

                  const router = useRouter();
                  router.push({
                    path: `/${product_id}/obrigado`,
                    query,
                  });
                  return;
                }
                if (
                  Array.isArray(res?.sales) &&
                  res.sales.some((item: SaleElement) => !item.success)
                ) {
                  this.validateError(res?.sales[0]);
                  return;
                }
                if (res.status === "error" && !res.sales?.success) {
                  this.validateError(res);
                  return;
                }
              })
              .catch((err) => {
                console.error(err);
                checkoutStore.setLoading(false);
                this.setPaymentLoading(false);
              })
              .finally(() => {
                this.setPaymentFetching(false);
                this.setPaymentLoading(false);
              });
          }
        } catch (error) {
          // Se ocorrer um erro em qualquer uma das promessas, ele será capturado aqui
          console.error("Erro:", error);
        }
      } else {
        this.setPaymentFetching(false);
        this.setPaymentLoading(false);
      }
    },
    validateError(error: PaymentError) {
      const purchaseStore = usePurchaseStore();

      const checkoutStore = useCheckoutStore();

      const { product_id } = checkoutStore;

      checkoutStore.setLoading(false);
      this.loading = false;

      switch (error.code) {
        case "TICKET_UNAVAILABLE":
          this.error_message = "error.TICKET_UNAVAILABLE";
          break;
          case "87": 
          this.error_message = "error.BAD_TRACK_2_DATA";
          break;
        case "0001":
          this.error_message = "error.0001";
          // this.resetCheckout("CARD");
          break;
        case "BANK":
          this.error_message = "error.BANK";
          // this.resetCheckout("ALL");
          break;
        case "BLACKLIST_PURCHASE":
          this.error_message = "error.BLACKLIST_PURCHASE";
          // this.resetCheckout("ALL");
          break;
        case "INVALID_CVV":
          this.error_message = "error.INVALID_CVV";
          // this.resetCheckout("CVV");
          break;
        case "INVALID_CLIENT_DATA":
          this.error_message = "error.INVALID_CLIENT_DATA";
          // this.resetCheckout("ALL");
          break;
        case "DUPLICATE_PURCHASE":
          this.error_message = "error.DUPLICATE_PURCHASE";
          // this.resetCheckout("ALL");
          break;
        case "PRODUCT_OUT_OF_STOCK":
          this.error_message = "error.PRODUCT_OUT_OF_STOCK";
          // this.resetCheckout("ALL");
          break;
        case "CREDIT_CARD_OPERATOR":
          this.error_message = "error.CREDIT_CARD_OPERATOR";
          // this.resetCheckout("ALL");
          break;
        case "INVALID_DATA":
          this.error_message = "error.INVALID_DATA";
          // this.resetCheckout("CARD");
          break;
        case "WORLDPAY_CARD_ERROR":
          this.error_message = "error.WORLDPAY_CARD_ERROR";
          break;
        case "INVALID_CREDIT_CARD":
          this.error_message = "error.INVALID_CREDIT_CARD";
          purchaseStore.resetCardState();
          // this.resetCheckout("ALL");
          break;
        case "INSUFFICIENT_FUNDS":
          this.error_message = "error.INSUFFICIENT_FUNDS";
          // this.resetCheckout("CARD");
          break;
        case "INVALID_PAYMENT_TYPE":
          this.error_message = "error.INVALID_PAYMENT_TYPE";
          // this.resetCheckout("ALL");
          break;
        case "INVALID_INSTALLMENTS":
          this.error_message = "error.INVALID_INSTALLMENTS";
          // this.resetCheckout("CARD");
          break;
        case "INVALID_INSTALLMENTS_BUMP":
          this.error_message = "error.INVALID_INSTALLMENTS_BUMP";
          // this.resetCheckout("CARD");
          break;
        case "CURRENCY_NOT_SUPPORTED":
          this.error_message = "error.CURRENCY_NOT_SUPPORTED";
          // this.resetCheckout("CARD");
          break;
        case "SUSPECTED_FRAUD":
          this.error_message = "error.SUSPECTED_FRAUD";
          // this.resetCheckout("ALL");
          break;
        case "EXPIRED_RATE_TOKEN":
          this.error_message = "error.EXPIRED_RATE_TOKEN";
          break;
        case "CREDIT_CARD_INVALID":
          this.error_message = "error.CREDIT_CARD_INVALID";
          purchaseStore.resetCardState();

          break;
        case "SUSPECTED_INTERN_FRAUD":
          this.error_message = "error.SUSPECTED_INTERN_FRAUD";
          break;
        case "INCOMPLETE_ADDRESS":
          this.error_message = "error.INCOMPLETE_ADDRESS";
          break;
        case "GENERIC":
        default:
          this.error_message = "error.GENERIC";
                    // this.resetCheckout("ALL");
          break;
      }

      GreennLogs.logger.info("🔴 Error Compra", {
        name: "Erro na Compra",
        product_id: product_id,
        error_code: error ? error.code : null,
        error_mensage: this.error_message,
      });
    },
    isPurcharseCard(card: any): card is PurcharseCard {
      return (
        typeof card.amount !== "undefined" &&
        typeof card.card_cvv === "string" &&
        typeof card.card_expiration_date === "string" &&
        typeof card.card_holder_name === "string" &&
        typeof card.card_number === "string"
      );
    },
    async priorityGateway(dataGateway: any) {
      const toast = Toast.useToast();
      const { product_global_settings } = useProductStore()
      
      const setting = product_global_settings.find(store => store.key === 'FINGERPRINT_SETTINGS')
      const fingerSetting = setting.value === "ENABLED"
      try {
        
        //Tem que passar true para dizer que é uma rota que usa o endpoint do gateway
        const response = await useApi().create(
          "/checkout/priority",
          dataGateway,
          null,
          true,
          false,
          false,
          fingerSetting
        );
        if(response && response.code && response.code == '400'){
          throw response;
        }

        return response;
      } catch (error) {
        // Tratar erros
        throw error; // Lançar o erro novamente para que ele possa ser tratado onde a função priorityGateway() foi chamada
      }
    },
    documentType(data: any):string {
       //Essa parte modifiquei pois o New Checkout não tem venda internacional
      return data.document.length > 14 ? 'cnpj' : 'cpf';
    },
    customerData(data: any): any {
      let document_number = data.document.replace(/\D/g, "");
      let document_type = this.documentType(data);
      let zipcodeFormatted = data.zipcode
        ? data.zipcode.slice(0, 5) + "-" + data.zipcode.slice(5)
        : null;

      let document = {};
      if (document_number) {
        document = {
          document: {
            type: document_type,
            number: document_number,
            document_type: document_type,
            document_number: document_number,
          },
        };
      }

      let address = {};
      if (data.city) {
        address = {
          address: {
            street: data.street,
            street_number: data.number,
            state: data.state || data.uf,
            city: data.city,
            neighborhood: data.neighborhood,
            zipcode: zipcodeFormatted,
          },
        };
      }

      data.client_id = null; // Passando como nulo, pq até então o client não foi criado
      return {
        external_id: String(data.client_id),
        name: data.name,
        phone: data.cellphone,
        email: data.email,
        document_number: document_number,
        document_type: document_type,
        ...document,
        ...address,
      };
    },
    async retryPayment(language: string,isUpdateSubscription: boolean){
      try {
        this.setPaymentLoading(false);
        this.setPaymentFetching(false);
        return this.payment(language,isUpdateSubscription);
      } catch (error) {
        console.error(error);
      }
    
    }
   
  },
});
