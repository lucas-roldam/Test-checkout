export const useSubscriptionStore = defineStore("subscription", {
  state: () => ({
    subscription: null
  }),
  getters: {
  },
  actions: {
  },
});
