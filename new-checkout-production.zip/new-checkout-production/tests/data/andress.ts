export const addressData = {
    cep: '87800-000',
    street: 'Avenida Brasil',
    number: '2379',
    neighborhood: 'Centro',
    complement: 'Andar 02',
    city: 'Rondon',
    state: 'PR'
  };