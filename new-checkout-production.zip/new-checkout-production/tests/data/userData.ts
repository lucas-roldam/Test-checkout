export const userData = {
    name: 'Tanielson Moura',
    email: 'tanielson@greenn.com.br',
    phone: '+55 44998741312',
    document: '707.952.041-08',
  };